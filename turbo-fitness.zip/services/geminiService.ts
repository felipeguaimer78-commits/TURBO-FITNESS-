
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Activity, TrainingPlan, PerformanceStats, FoodLog } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeDietAndAdjust = async (foodDescription: string): Promise<{calories: number, isOffPlan: boolean, advice: string}> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analise esta refeição: "${foodDescription}". Estime as calorias e diga se é uma "fugida da dieta". Dê um conselho motivacional curto.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          calories: { type: Type.NUMBER },
          isOffPlan: { type: Type.BOOLEAN },
          advice: { type: Type.STRING }
        },
        required: ["calories", "isOffPlan", "advice"]
      }
    }
  });
  return JSON.parse(response.text || "{}");
};

export const analyzeFoodImage = async (base64Image: string): Promise<{description: string, calories: number, isOffPlan: boolean, advice: string}> => {
  // Remove data:image/jpeg;base64, prefix if present
  const base64Data = base64Image.includes(',') ? base64Image.split(',')[1] : base64Image;
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Data, mimeType: 'image/jpeg' } },
        { text: "Identifique os alimentos nesta imagem. Retorne uma descrição clara do prato, uma estimativa de calorias totais, se é considerado 'fora da dieta' e um conselho nutricional breve." }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          description: { type: Type.STRING },
          calories: { type: Type.NUMBER },
          isOffPlan: { type: Type.BOOLEAN },
          advice: { type: Type.STRING }
        },
        required: ["description", "calories", "isOffPlan", "advice"]
      }
    }
  });
  return JSON.parse(response.text || "{}");
};

export const analyzeForm = async (base64Image: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType: 'image/jpeg' } },
        { text: "Analise a postura deste exercício físico. Seja breve e técnico." }
      ]
    }
  });
  return response.text || "Não foi possível analisar a postura.";
};

export const getTrainingPlan = async (userGoal: string, recentHistory: Activity[], dietLogs: FoodLog[]): Promise<TrainingPlan> => {
  const historyText = recentHistory.map(a => `${a.type}: ${a.distance || 0}m`).join(', ');
  const dietText = dietLogs.map(d => d.description).join(', ');
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Gere um plano de 7 dias. Objetivo: "${userGoal}". Histórico: ${historyText}. Dieta recente: ${dietText}. Se houve fugida da dieta, compense com cardio.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          goal: { type: Type.STRING },
          workouts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                day: { type: Type.INTEGER },
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                type: { type: Type.STRING },
                intensity: { type: Type.STRING },
                durationMinutes: { type: Type.INTEGER }
              },
              required: ["day", "title", "description", "type", "intensity", "durationMinutes"]
            }
          },
          startDate: { type: Type.STRING },
          endDate: { type: Type.STRING }
        },
        required: ["id", "goal", "workouts", "startDate", "endDate"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
};

export const getPerformanceInsights = async (activities: Activity[]): Promise<PerformanceStats> => {
  const historyText = activities.slice(0, 10).map(a => `${a.type}: ${a.distance || 0}m, effort: ${a.perceivedExertion}`).join('; ');
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze physical performance history: ${historyText}. Provide metrics (0-100) and race predictions.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          fatigue: { type: Type.NUMBER },
          fitness: { type: Type.NUMBER },
          recovery: { type: Type.NUMBER },
          dietScore: { type: Type.NUMBER },
          predictedTimes: {
            type: Type.OBJECT,
            properties: {
              '5k': { type: Type.STRING },
              '10k': { type: Type.STRING },
              'HalfMarathon': { type: Type.STRING }
            },
            required: ['5k', '10k', 'HalfMarathon']
          }
        },
        required: ["fatigue", "fitness", "recovery", "dietScore", "predictedTimes"]
      }
    }
  });
  return JSON.parse(response.text || "{}");
};

export const playAudioFeedback = async (message: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Atenção Turbo: ${message}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Puck' }, // Voz mais energética
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const binaryString = atob(base64Audio);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
      const dataInt16 = new Int16Array(bytes.buffer);
      const buffer = audioCtx.createBuffer(1, dataInt16.length, 24000);
      const channelData = buffer.getChannelData(0);
      for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
      const source = audioCtx.createBufferSource();
      source.buffer = buffer;
      source.connect(audioCtx.destination);
      source.start();
    }
  } catch (e) {}
};
