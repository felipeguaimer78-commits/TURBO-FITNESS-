
import { Activity, FoodLog, UserProfile, TrainingPlan } from '../types';

const STORAGE_KEYS = {
  ACTIVITIES: 'turbo_cache_activities',
  FOOD_LOGS: 'turbo_cache_food',
  PROFILE: 'turbo_cache_profile',
  PLAN: 'turbo_cache_plan',
  LAST_SYNC: 'turbo_cache_last_sync'
};

export const CacheService = {
  saveActivities: (data: Activity[]) => {
    localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify(data.slice(0, 100))); // Cache top 100
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC, Date.now().toString());
  },

  getActivities: (): Activity[] => {
    const data = localStorage.getItem(STORAGE_KEYS.ACTIVITIES);
    return data ? JSON.parse(data) : [];
  },

  saveFoodLogs: (data: FoodLog[]) => {
    localStorage.setItem(STORAGE_KEYS.FOOD_LOGS, JSON.stringify(data.slice(0, 50))); // Cache top 50
  },

  getFoodLogs: (): FoodLog[] => {
    const data = localStorage.getItem(STORAGE_KEYS.FOOD_LOGS);
    return data ? JSON.parse(data) : [];
  },

  saveProfile: (data: UserProfile) => {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(data));
  },

  getProfile: (): UserProfile | null => {
    const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
    return data ? JSON.parse(data) : null;
  },

  savePlan: (data: TrainingPlan) => {
    localStorage.setItem(STORAGE_KEYS.PLAN, JSON.stringify(data));
  },

  getPlan: (): TrainingPlan | null => {
    const data = localStorage.getItem(STORAGE_KEYS.PLAN);
    return data ? JSON.parse(data) : null;
  },

  getLastSync: (): number => {
    const ts = localStorage.getItem(STORAGE_KEYS.LAST_SYNC);
    return ts ? parseInt(ts, 10) : 0;
  }
};
