
import React, { useState, useRef, useEffect } from 'react';
import { FoodLog, UserProfile } from '../types';
import { analyzeDietAndAdjust, analyzeFoodImage } from '../services/geminiService';
import { Apple, Plus, Info, Loader2, AlertCircle, TrendingDown, Target, Edit2, Flame, Camera, X, Check, RefreshCw, Zap } from 'lucide-react';

interface NutritionProps {
  onLog: (log: FoodLog) => void;
  logs: FoodLog[];
  userProfile: UserProfile;
  onUpdateProfile: (p: UserProfile) => void;
}

const Nutrition: React.FC<NutritionProps> = ({ onLog, logs, userProfile, onUpdateProfile }) => {
  const [input, setInput] = useState('');
  const [estimatedCalories, setEstimatedCalories] = useState<number | string>('');
  const [loading, setLoading] = useState(false);
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false);
  const [lastAdvice, setLastAdvice] = useState<string | null>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [tempPhoto, setTempPhoto] = useState<string | null>(null);
  const [isOffPlanSuggested, setIsOffPlanSuggested] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (isCameraOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [isCameraOpen]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Erro ao acessar câmera:", err);
      setIsCameraOpen(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      const w = videoRef.current.videoWidth;
      const h = videoRef.current.videoHeight;
      canvasRef.current.width = w;
      canvasRef.current.height = h;
      ctx?.drawImage(videoRef.current, 0, 0);
      
      const photoData = canvasRef.current.toDataURL('image/jpeg');
      setTempPhoto(photoData);
      setIsCameraOpen(false);
      
      analyzeCapturedImage(photoData);
    }
  };

  const analyzeCapturedImage = async (base64: string) => {
    setIsAnalyzingImage(true);
    try {
      const result = await analyzeFoodImage(base64);
      setInput(result.description);
      setEstimatedCalories(result.calories);
      setIsOffPlanSuggested(result.isOffPlan);
      setLastAdvice(result.advice);
    } catch (error) {
      console.error("Erro na análise automática:", error);
    } finally {
      setIsAnalyzingImage(false);
    }
  };

  const handleLog = async () => {
    if (!input) return;
    setLoading(true);
    try {
      let finalCalories = Number(estimatedCalories);
      let isOffPlan = isOffPlanSuggested;
      let advice = lastAdvice || "";

      if (!finalCalories || isNaN(finalCalories)) {
        const result = await analyzeDietAndAdjust(input);
        finalCalories = result.calories;
        isOffPlan = result.isOffPlan;
        advice = result.advice;
      }
      
      onLog({
        id: Date.now().toString(),
        description: input,
        timestamp: new Date().toISOString(),
        calories: finalCalories,
        isOffPlan: isOffPlan,
        photoUrl: tempPhoto || undefined
      });
      
      setLastAdvice(advice);
      setInput('');
      setEstimatedCalories('');
      setTempPhoto(null);
      setIsOffPlanSuggested(false);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const getIncentive = () => {
    const diff = userProfile.currentWeight - userProfile.targetWeight;
    const absDiff = Math.abs(diff).toFixed(1);
    if (userProfile.goalType === 'LOSE') {
      return `Restam ${absDiff}kg para o seu ápice físico. Cada caloria é uma decisão tática.`;
    } else if (userProfile.goalType === 'GAIN') {
      return `Faltam ${absDiff}kg de massa bruta. Construa seu legado grama por grama.`;
    }
    return "O equilíbrio é a maestria do atleta. Mantenha o foco.";
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-start px-1">
        <div className="space-y-1.5">
          <h2 className="text-3xl font-black italic text-yellow-400 uppercase tracking-tighter leading-none">PROTOCOLO<br/>ALIMENTAR</h2>
          <p className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.3em] italic">
            Meta: {userProfile.goalType === 'LOSE' ? 'Déficit Calórico' : userProfile.goalType === 'GAIN' ? 'Superávit Bio' : 'Equilíbrio'}
          </p>
        </div>
        <button onClick={() => setIsEditingProfile(!isEditingProfile)} className="p-4 bg-zinc-900 rounded-[1.5rem] text-zinc-500 hover:text-yellow-400 border border-zinc-800 transition-all active:scale-90 shadow-xl">
          <Edit2 size={20} />
        </button>
      </header>

      {isEditingProfile && (
        <div className="bg-zinc-900 border-2 border-yellow-400 p-8 rounded-[2.5rem] space-y-6 animate-in zoom-in-95 shadow-2xl">
          <div className="flex items-center gap-3">
            <Target size={20} className="text-yellow-400" />
            <h3 className="font-black italic text-yellow-400 uppercase text-sm tracking-widest">RECALIBRAR METAS</h3>
          </div>
          <div className="grid grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-[9px] font-black text-zinc-600 uppercase tracking-widest italic px-2">Peso Atual (kg)</label>
              <input 
                type="number" 
                defaultValue={userProfile.currentWeight} 
                onBlur={(e) => onUpdateProfile({...userProfile, currentWeight: Number(e.target.value)})}
                className="w-full bg-black p-5 rounded-2xl border border-zinc-800 font-black italic text-2xl text-white outline-none focus:border-yellow-400 shadow-inner"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[9px] font-black text-zinc-600 uppercase tracking-widest italic px-2">Peso Alvo (kg)</label>
              <input 
                type="number" 
                defaultValue={userProfile.targetWeight}
                onBlur={(e) => onUpdateProfile({...userProfile, targetWeight: Number(e.target.value)})}
                className="w-full bg-black p-5 rounded-2xl border border-zinc-800 font-black italic text-2xl text-yellow-400 outline-none focus:border-yellow-400 shadow-inner"
              />
            </div>
          </div>
          <button onClick={() => setIsEditingProfile(false)} className="w-full bg-yellow-400 text-black py-5 rounded-2xl font-black italic uppercase text-xs tracking-[0.3em] shadow-xl shadow-yellow-400/10 active:scale-95 transition-all">SINCRONIZAR METAS</button>
        </div>
      )}

      <section className="bg-gradient-to-br from-yellow-400 to-orange-500 p-8 rounded-[2.5rem] text-black shadow-2xl relative overflow-hidden group">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/20 blur-3xl rounded-full transition-transform duration-1000 group-hover:scale-125"></div>
        <div className="flex items-center gap-3 mb-4 relative z-10">
          <Flame size={24} strokeWidth={3} className="animate-bounce" />
          <span className="font-black italic uppercase text-[10px] tracking-[0.4em]">MENTALIDADE TURBO</span>
        </div>
        <p className="text-xl font-black italic leading-tight relative z-10 uppercase tracking-tighter">"{getIncentive()}"</p>
      </section>

      <div className="bg-zinc-900 border border-zinc-800 rounded-[2.5rem] p-8 sm:p-10 space-y-6 shadow-2xl">
        <div className="space-y-5">
          <div className="flex items-center justify-between px-2">
            <label className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.3em] italic">Módulo de Entrada</label>
            {tempPhoto && (
              <button onClick={() => { setTempPhoto(null); setInput(''); setEstimatedCalories(''); }} className="text-[9px] font-black text-red-500 uppercase flex items-center gap-1.5 active:scale-95">
                <X size={12} strokeWidth={3} /> Cancelar Captura
              </button>
            )}
          </div>
          
          <div className="flex flex-col gap-5">
            <div className="relative">
              <textarea 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="w-full bg-black border border-zinc-800 rounded-[2rem] p-6 pr-16 text-sm font-bold focus:border-yellow-400 outline-none transition-all placeholder:text-zinc-800 text-zinc-100 min-h-[120px] resize-none shadow-inner"
                placeholder={isAnalyzingImage ? "Sincronizando com banco de dados..." : "Descreva seu abastecimento ou use a câmera..."}
              />
              <button 
                onClick={() => setIsCameraOpen(true)}
                className={`absolute right-4 top-4 w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-2xl active:scale-90 ${tempPhoto ? 'bg-emerald-500 text-black shadow-emerald-500/20' : 'bg-zinc-800 text-zinc-500 border border-zinc-700 hover:text-white'}`}
              >
                {isAnalyzingImage ? <Loader2 size={24} className="animate-spin text-yellow-400" /> : (tempPhoto ? <Check size={24} strokeWidth={3} /> : <Camera size={24} />)}
              </button>
            </div>

            {tempPhoto && (
              <div className="relative w-full h-64 rounded-[2.5rem] overflow-hidden border-2 border-yellow-400/20 animate-in zoom-in-95 group shadow-2xl">
                <img src={tempPhoto} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                
                {isAnalyzingImage && (
                  <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex flex-col items-center justify-center gap-4">
                    <RefreshCw size={36} className="text-yellow-400 animate-spin" />
                    <p className="text-[11px] font-black text-white uppercase italic tracking-widest animate-pulse">Análise Biopsicossocial...</p>
                  </div>
                )}

                {!isAnalyzingImage && (
                  <div className="absolute bottom-6 left-8 right-8 flex justify-between items-end">
                    <p className="text-[10px] font-black text-yellow-400 uppercase italic tracking-widest">Protocolo Identificado</p>
                    <div className="bg-black/90 backdrop-blur-xl px-5 py-3 rounded-2xl border border-white/10 flex items-center gap-3">
                       <Flame size={16} className="text-orange-500" />
                       <input 
                         type="number" 
                         value={estimatedCalories}
                         onChange={(e) => setEstimatedCalories(e.target.value)}
                         className="bg-transparent w-16 text-white font-black italic text-right outline-none text-xl"
                       />
                       <span className="text-[10px] font-black text-zinc-600 uppercase">KCAL</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {!tempPhoto && input && (
               <div className="flex justify-end px-2">
                 <div className="bg-zinc-800/80 px-5 py-2.5 rounded-2xl border border-zinc-700/50 flex items-center gap-3 animate-in fade-in">
                    <Zap size={14} className="text-yellow-400" fill="currentColor" />
                    <span className="text-[10px] font-black text-zinc-500 uppercase italic tracking-tight">Estimação Automática:</span>
                    <input 
                      type="number" 
                      placeholder="---"
                      value={estimatedCalories}
                      onChange={(e) => setEstimatedCalories(e.target.value)}
                      className="bg-transparent w-14 text-white font-black italic text-right outline-none text-base"
                    />
                    <span className="text-[10px] font-black text-zinc-600">KCAL</span>
                 </div>
               </div>
            )}

            <button 
              disabled={loading || isAnalyzingImage || !input}
              onClick={handleLog}
              className="w-full bg-yellow-400 text-black font-black py-6 rounded-[2rem] flex items-center justify-center gap-4 active:scale-95 shadow-2xl transition-all italic uppercase tracking-[0.2em] text-sm disabled:opacity-40"
            >
              {loading ? <Loader2 size={24} className="animate-spin" /> : <Plus size={24} strokeWidth={3} />}
              {tempPhoto ? 'CONFIRMAR PROTOCOLO' : 'REGISTRAR MACROS'}
            </button>
          </div>
        </div>
        
        {lastAdvice && (
          <div className="bg-zinc-800/30 border border-yellow-400/10 p-6 rounded-[2rem] flex gap-5 animate-in slide-in-from-top-4 duration-500">
            <Info size={24} className="text-yellow-400 flex-shrink-0" />
            <p className="text-xs text-yellow-100/70 leading-relaxed font-bold italic tracking-tight uppercase leading-snug">"{lastAdvice}"</p>
          </div>
        )}
      </div>

      <section className="pb-16 px-1">
        <div className="flex justify-between items-center mb-6 px-4">
           <h3 className="text-sm font-black text-zinc-500 uppercase tracking-[0.3em] italic flex items-center gap-3">
              <Apple size={16} className="text-emerald-500" /> Log de Hoje
           </h3>
           <span className="text-[9px] font-black text-zinc-600 bg-zinc-900 px-4 py-1.5 rounded-full border border-zinc-800 uppercase italic">Sessões: {logs.length}</span>
        </div>
        <div className="space-y-5">
          {logs.length === 0 && (
            <div className="text-center py-20 bg-zinc-900/10 border-2 border-dashed border-zinc-900 rounded-[2.5rem]">
               <Apple size={40} className="mx-auto text-zinc-900 mb-4 opacity-40" />
               <p className="text-zinc-800 font-black italic uppercase text-[10px] tracking-widest">Aguardando dados de nutrição...</p>
            </div>
          )}
          {logs.map(log => (
            <div key={log.id} className="bg-zinc-900/60 border border-zinc-800 p-4 rounded-[2.5rem] flex items-center gap-5 group hover:border-zinc-700 transition-all animate-in fade-in slide-in-from-bottom-4 shadow-xl active:scale-[0.98]">
              <div className="w-24 h-24 rounded-[1.8rem] bg-black overflow-hidden flex-shrink-0 relative shadow-2xl">
                {log.photoUrl ? (
                  <img src={log.photoUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                ) : (
                  <div className={`w-full h-full flex items-center justify-center ${log.isOffPlan ? 'text-red-500/50' : 'text-emerald-400/50'}`}>
                    {log.isOffPlan ? <AlertCircle size={32} /> : <TrendingDown size={32} />}
                  </div>
                )}
                {log.isOffPlan && (
                  <div className="absolute top-2 right-2 bg-red-500 rounded-full p-1 shadow-2xl">
                    <AlertCircle size={12} className="text-white" />
                  </div>
                )}
              </div>
              <div className="flex-1 pr-6 min-w-0">
                <div className="flex justify-between items-start mb-2">
                   <h4 className="text-[13px] font-black italic text-zinc-100 uppercase tracking-tight truncate">{log.description}</h4>
                   <p className="text-[9px] text-zinc-600 font-black uppercase italic whitespace-nowrap ml-2">{new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black italic text-white tracking-tighter leading-none">{log.calories}</span>
                  <span className="text-[10px] text-zinc-700 font-black uppercase tracking-tighter italic">KCAL</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {isCameraOpen && (
        <div className="fixed inset-0 z-[400] bg-black flex flex-col animate-in fade-in duration-300">
           <div className="relative flex-1 bg-black overflow-hidden">
             <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
             <div className="absolute inset-0 border-[50px] border-black/60 pointer-events-none flex items-center justify-center">
                <div className="w-full h-72 border-2 border-yellow-400/40 rounded-[3rem] shadow-[0_0_80px_rgba(250,204,21,0.15)]"></div>
             </div>
             <div className="absolute top-16 left-0 right-0 text-center">
               <span className="bg-black/90 text-yellow-400 px-8 py-4 rounded-full font-black italic uppercase text-[11px] tracking-[0.3em] border border-yellow-400/20 backdrop-blur-2xl shadow-2xl">
                 ESCANEANDO ABASTECIMENTO
               </span>
             </div>
           </div>
           
           <div className="h-44 bg-black flex items-center justify-around border-t border-zinc-900 safe-bottom px-10">
              <button onClick={() => setIsCameraOpen(false)} className="p-5 bg-zinc-900 rounded-full text-zinc-500 hover:text-white transition-colors">
                <X size={28} />
              </button>
              <button 
                onClick={capturePhoto}
                className="w-24 h-24 bg-yellow-400 rounded-full border-[8px] border-zinc-950 shadow-[0_0_0_4px_#facc15] flex items-center justify-center text-black active:scale-90 transition-all shadow-yellow-400/20"
              >
                <Camera size={40} strokeWidth={3} />
              </button>
              <div className="w-16 h-16"></div>
           </div>
        </div>
      )}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};

export default Nutrition;
