
import React, { useState, useEffect } from 'react';
import { ExerciseDefinition } from '../types';
import { 
  Search, 
  ChevronRight, 
  Dumbbell, 
  Zap, 
  Activity, 
  Info, 
  Star, 
  Filter, 
  X, 
  ChevronDown, 
  AlertTriangle, 
  ShieldCheck, 
  PlayCircle,
  Hash
} from 'lucide-react';

export const MOCK_EXERCISES: ExerciseDefinition[] = [
  // PEITO
  { 
    id: 'p1', 
    name: 'Supino Reto (Barra)', 
    category: 'Peito', 
    level: 'Intermediário',
    equipment: 'Pesos Livres',
    secondaryMuscles: ['Tríceps', 'Ombros'],
    imageUrl: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=800&q=80', 
    description: 'O exercício base absoluto para construção de força e volume na musculatura peitoral.',
    steps: [
      'Deite no banco reto com os pés firmes no chão.',
      'Segure a barra com uma pegada ligeiramente mais larga que os ombros.',
      'Desça a barra controladamente até o meio do peito.',
      'Empurre a barra de volta à posição inicial sem travar os cotovelos.'
    ],
    commonErrors: [
      'Bater a barra no peito.',
      'Retirar os glúteos do banco.',
      'Cotovelos excessivamente abertos (90 graus).'
    ],
    tips: [
      'Mantenha as escápulas retraídas (fechadas) durante todo o movimento.',
      'Imagine que você está tentando entortar a barra para fora.'
    ],
    variations: ['Supino com Halteres', 'Supino Reto na Máquina']
  },
  { 
    id: 'p2', 
    name: 'Flexão de Braços', 
    category: 'Peito', 
    level: 'Iniciante',
    equipment: 'Peso Corporal',
    secondaryMuscles: ['Core', 'Tríceps'],
    imageUrl: 'https://images.unsplash.com/photo-1598971639058-aba7c02b3769?w=800&q=80', 
    description: 'Exercício fundamental de calistenia que trabalha peito, ombros e estabilidade do core.',
    steps: [
      'Posicione as mãos no chão sob os ombros.',
      'Mantenha o corpo em linha reta da cabeça aos pés.',
      'Desça até que o peito quase toque o chão.',
      'Empurre para cima mantendo o abdômen contraído.'
    ],
    commonErrors: [
      'Deixar o quadril cair.',
      'Olhar para a frente (force o pescoço).',
      'Mãos muito à frente da linha do ombro.'
    ],
    tips: [
      'Se estiver difícil, comece com os joelhos apoiados.',
      'Mantenha os cotovelos a 45 graus do corpo.'
    ]
  },
  
  // COSTAS
  { 
    id: 'c1', 
    name: 'Barra Fixa (Pull-up)', 
    category: 'Costas', 
    level: 'Avançado',
    equipment: 'Peso Corporal',
    secondaryMuscles: ['Bíceps', 'Antebraço'],
    imageUrl: 'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=800&q=80', 
    description: 'O padrão ouro para largura das costas e força relativa do membro superior.',
    steps: [
      'Segure a barra com as mãos em pronação (palmas para frente).',
      'Inicie o movimento puxando os cotovelos para baixo.',
      'Suba até que o queixo ultrapasse a barra.',
      'Desça controladamente até estender quase totalmente os braços.'
    ],
    commonErrors: [
      'Usar impulso das pernas (kipping).',
      'Amplitude parcial.',
      'Ombros subindo em direção às orelhas.'
    ],
    tips: [
      'Tente "quebrar" a barra para fora para ativar mais as dorsais.',
      'Imagine levar o peito à barra, não o queixo.'
    ]
  },
  { 
    id: 'c2', 
    name: 'Remada Baixa (Triângulo)', 
    category: 'Costas', 
    level: 'Iniciante',
    equipment: 'Cabos',
    secondaryMuscles: ['Bíceps', 'Trapézio'],
    imageUrl: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?w=800&q=80', 
    description: 'Excelente para densidade das costas e postura.',
    steps: [
      'Sente com os joelhos levemente flexionados.',
      'Puxe o triângulo em direção ao abdômen inferior.',
      'Aperte as escápulas no final do movimento.',
      'Retorne alongando as costas sem curvar a coluna.'
    ],
    commonErrors: [
      'Balançar o tronco excessivamente.',
      'Encolher os ombros na puxada.'
    ],
    tips: [
      'Pense em puxar com os cotovelos, não com as mãos.'
    ]
  },

  // PERNAS
  { 
    id: 'l1', 
    name: 'Agachamento Livre (Barra)', 
    category: 'Pernas', 
    level: 'Intermediário',
    equipment: 'Pesos Livres',
    secondaryMuscles: ['Glúteos', 'Lombar', 'Core'],
    imageUrl: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=800&q=80', 
    description: 'O rei dos exercícios. Constrói força bruta e massa muscular em todo o corpo.',
    steps: [
      'Posicione a barra sobre o trapézio.',
      'Afaste os pés na largura dos ombros.',
      'Desça o quadril como se fosse sentar em uma cadeira.',
      'Mantenha o peito aberto e desça até as coxas ficarem paralelas ao chão.'
    ],
    commonErrors: [
      'Joelhos "entrando" (valgo dinâmico).',
      'Calcanhares saindo do chão.',
      'Arredondar a lombar (butt wink).'
    ],
    tips: [
      'Empurre o chão com os calcanhares.',
      'Inspire antes de descer e segure o ar para estabilizar o core.'
    ]
  },
  { 
    id: 'f1', 
    name: 'Kettlebell Swing', 
    category: 'Funcional', 
    level: 'Intermediário',
    equipment: 'Kettlebell',
    secondaryMuscles: ['Glúteos', 'Posterior de Coxa', 'Ombros'],
    imageUrl: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800&q=80', 
    description: 'Exercício explosivo de potência de quadril e condicionamento metabólico.',
    steps: [
      'Pés afastados, kettlebell no chão à frente.',
      'Faça o movimento de dobradiça de quadril (hip hinge).',
      'Puxe o peso entre as pernas e exploda o quadril para frente.',
      'O peso deve subir até a altura do peito pela força do quadril.'
    ],
    commonErrors: [
      'Agachar em vez de fazer o movimento de dobradiça.',
      'Puxar o peso com os braços.'
    ],
    tips: [
      'Imagine que você está tentando arremessar o kettlebell para frente com o quadril.'
    ]
  },

  // MOBILIDADE / ALONGAMENTO
  { 
    id: 'm1', 
    name: 'Gato-Camelo', 
    category: 'Mobilidade', 
    level: 'Iniciante',
    equipment: 'Peso Corporal',
    secondaryMuscles: ['Coluna'],
    imageUrl: 'https://images.unsplash.com/photo-1566241142559-40e1bfc26ec7?w=800&q=80', 
    description: 'Excelente para lubrificação das vértebras e saúde da coluna.',
    steps: [
      'Fique em quatro apoios.',
      'Arredonde as costas para cima como um gato, olhando para o umbigo.',
      'Afunde as costas para baixo, olhando suavemente para cima.'
    ],
    commonErrors: ['Movimentos bruscos.'],
    tips: ['Sincronize com a respiração. Inspire ao afundar, expire ao arredondar.']
  }
];

const ExerciseLibrary: React.FC = () => {
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState<string | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [selectedEquip, setSelectedEquip] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [selectedExercise, setSelectedExercise] = useState<ExerciseDefinition | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('turbo_fav_exercises');
    if (saved) setFavorites(JSON.parse(saved));
  }, []);

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newFavs = favorites.includes(id) 
      ? favorites.filter(f => f !== id) 
      : [...favorites, id];
    setFavorites(newFavs);
    localStorage.setItem('turbo_fav_exercises', JSON.stringify(newFavs));
  };

  const categories = ['Peito', 'Costas', 'Pernas', 'Ombros', 'Braços', 'Core', 'Cardio', 'Alongamento', 'Mobilidade', 'Funcional'];
  const levels = ['Iniciante', 'Intermediário', 'Avançado'];
  const equipments = ['Pesos Livres', 'Máquinas', 'Cabos', 'Peso Corporal', 'Elásticos', 'Kettlebell', 'Bola'];

  const filtered = MOCK_EXERCISES.filter(ex => 
    ex.name.toLowerCase().includes(search.toLowerCase()) && 
    (!selectedCat || ex.category === selectedCat) &&
    (!selectedLevel || ex.level === selectedLevel) &&
    (!selectedEquip || ex.equipment === selectedEquip)
  );

  return (
    <div className="space-y-6 pb-32 animate-in fade-in duration-500">
      <header className="flex flex-col gap-1 px-2">
        <h2 className="text-4xl font-black italic text-yellow-400 uppercase tracking-tighter leading-none">BIBLIOTECA<br/><span className="text-white">TURBO ELITE</span></h2>
        <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.4em] italic mt-1">Sincronizado com Bases de Dados Globais</p>
      </header>

      {/* Barra de Pesquisa e Filtros */}
      <div className="space-y-3 px-2">
        <div className="flex gap-2">
          <div className="relative flex-1 group">
            <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
              <Search className="text-zinc-600 group-focus-within:text-yellow-400 transition-colors" size={18} />
            </div>
            <input 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-[2.5rem] py-6 pl-14 pr-6 text-sm font-bold focus:border-yellow-400 outline-none transition-all placeholder:text-zinc-800 text-zinc-100 shadow-xl"
              placeholder="Pesquisar protocolo..."
            />
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center transition-all ${showFilters || selectedLevel || selectedEquip ? 'bg-yellow-400 text-black' : 'bg-zinc-900 border border-zinc-800 text-zinc-500'}`}
          >
            <Filter size={24} />
          </button>
        </div>

        {showFilters && (
          <div className="bg-zinc-900/80 backdrop-blur-xl border border-zinc-800 rounded-[2rem] p-6 space-y-4 animate-in slide-in-from-top-4">
             <div className="space-y-3">
               <label className="text-[9px] font-black text-zinc-600 uppercase tracking-widest italic">Complexidade do Motor</label>
               <div className="flex flex-wrap gap-2">
                 {levels.map(l => (
                   <button key={l} onClick={() => setSelectedLevel(selectedLevel === l ? null : l)} className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase italic border ${selectedLevel === l ? 'bg-white text-black border-white' : 'border-zinc-800 text-zinc-500'}`}>{l}</button>
                 ))}
               </div>
             </div>
             <div className="space-y-3">
               <label className="text-[9px] font-black text-zinc-600 uppercase tracking-widest italic">Módulo de Equipamento</label>
               <div className="flex flex-wrap gap-2">
                 {equipments.map(e => (
                   <button key={e} onClick={() => setSelectedEquip(selectedEquip === e ? null : e)} className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase italic border ${selectedEquip === e ? 'bg-white text-black border-white' : 'border-zinc-800 text-zinc-500'}`}>{e}</button>
                 ))}
               </div>
             </div>
             <button onClick={() => {setSelectedLevel(null); setSelectedEquip(null); setShowFilters(false);}} className="w-full py-3 text-[10px] font-black text-yellow-400 uppercase italic tracking-widest">Limpar Parâmetros</button>
          </div>
        )}
      </div>

      {/* Categorias */}
      <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar px-2">
        <button 
          onClick={() => setSelectedCat(null)}
          className={`px-8 py-4 rounded-[1.5rem] text-[10px] font-black italic uppercase whitespace-nowrap border-2 transition-all active:scale-90 ${!selectedCat ? 'bg-yellow-400 border-yellow-400 text-black shadow-lg shadow-yellow-500/20' : 'bg-zinc-900 border-zinc-800 text-zinc-600 hover:border-zinc-700'}`}
        >
          TUDO
        </button>
        {categories.map(cat => (
          <button 
            key={cat}
            onClick={() => setSelectedCat(cat)}
            className={`px-8 py-4 rounded-[1.5rem] text-[10px] font-black italic uppercase whitespace-nowrap border-2 transition-all active:scale-90 ${selectedCat === cat ? 'bg-yellow-400 border-yellow-400 text-black shadow-lg shadow-yellow-500/20' : 'bg-zinc-900 border-zinc-800 text-zinc-600 hover:border-zinc-700'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Lista de Cards */}
      <div className="grid grid-cols-1 gap-6 px-2">
        {filtered.map(ex => (
          <div 
            key={ex.id} 
            onClick={() => setSelectedExercise(ex)}
            className="bg-zinc-900 border border-zinc-800 rounded-[3rem] overflow-hidden group active:scale-[0.98] transition-all cursor-pointer hover:border-yellow-400/30 shadow-2xl relative"
          >
            <div className="relative h-72 overflow-hidden">
               <img src={ex.imageUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 grayscale group-hover:grayscale-0 opacity-40 group-hover:opacity-90" alt={ex.name} />
               <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
               
               <div className="absolute top-6 left-6 right-6 flex justify-between items-start">
                  <div className="flex flex-col gap-2">
                    <span className="bg-yellow-400 text-black text-[9px] font-black px-3 py-1 rounded-full uppercase italic tracking-widest w-fit shadow-lg">{ex.category}</span>
                    <span className="bg-black/60 backdrop-blur-md text-white text-[8px] font-black px-3 py-1 rounded-full uppercase italic tracking-widest w-fit border border-white/10">{ex.level}</span>
                  </div>
                  <button 
                    onClick={(e) => toggleFavorite(ex.id, e)}
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-xl active:scale-90 backdrop-blur-md border ${favorites.includes(ex.id) ? 'bg-yellow-400 border-yellow-400 text-black' : 'bg-black/40 border-white/10 text-zinc-500 hover:text-white'}`}
                  >
                    <Star size={20} fill={favorites.includes(ex.id) ? "currentColor" : "none"} />
                  </button>
               </div>

               <div className="absolute bottom-8 left-10 right-10">
                  <h3 className="text-4xl font-black italic text-white uppercase tracking-tighter leading-none mb-2 group-hover:text-yellow-400 transition-colors">{ex.name}</h3>
                  <div className="flex items-center gap-4 text-zinc-500 font-black italic uppercase text-[9px] tracking-widest">
                     <span className="flex items-center gap-1.5"><Dumbbell size={12} /> {ex.equipment}</span>
                     <span className="flex items-center gap-1.5"><Activity size={12} /> {ex.secondaryMuscles?.join(', ')}</span>
                  </div>
               </div>
            </div>
            
            <div className="p-8 flex justify-between items-center bg-black/40 backdrop-blur-xl border-t border-zinc-800/50">
               <p className="text-[11px] text-zinc-500 font-bold italic leading-relaxed uppercase tracking-tight line-clamp-2 pr-4">{ex.description}</p>
               <div className="bg-zinc-800 p-4 rounded-2xl text-zinc-500 group-hover:bg-yellow-400 group-hover:text-black transition-all shadow-xl group-hover:translate-x-1">
                  <ChevronRight size={24} strokeWidth={4} />
               </div>
            </div>
          </div>
        ))}
      </div>
      
      {filtered.length === 0 && (
        <div className="py-32 text-center space-y-4">
          <Activity size={80} className="mx-auto text-zinc-900 animate-pulse" />
          <p className="text-zinc-700 font-black italic uppercase text-xs tracking-[0.5em]">Protocolo Fora de Alcance</p>
          <button onClick={() => {setSearch(''); setSelectedCat(null); setSelectedLevel(null); setSelectedEquip(null);}} className="text-yellow-400 text-[10px] font-black uppercase italic underline">Resetar Sistema</button>
        </div>
      )}

      {/* Modal de Detalhes do Exercício */}
      {selectedExercise && (
        <div className="fixed inset-0 z-[1000] bg-black/95 backdrop-blur-2xl overflow-y-auto no-scrollbar animate-in fade-in zoom-in-95 duration-300">
           <div className="min-h-screen pb-32">
              <div className="relative h-[45vh] w-full">
                 <img src={selectedExercise.imageUrl} className="w-full h-full object-cover" />
                 <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
                 <button 
                  onClick={() => setSelectedExercise(null)}
                  className="absolute top-10 right-8 w-14 h-14 bg-black/80 backdrop-blur-md rounded-full border border-white/10 flex items-center justify-center text-white active:scale-90 transition-all shadow-2xl"
                 >
                   <X size={28} />
                 </button>
                 
                 <div className="absolute bottom-10 left-8 right-8 space-y-4">
                    <div className="flex gap-2">
                       <span className="bg-yellow-400 text-black px-4 py-1.5 rounded-full text-[10px] font-black uppercase italic tracking-widest">{selectedExercise.category}</span>
                       <span className="bg-white/10 backdrop-blur-md text-white px-4 py-1.5 rounded-full text-[10px] font-black uppercase italic tracking-widest border border-white/10">{selectedExercise.level}</span>
                    </div>
                    <h2 className="text-6xl font-black italic text-white uppercase tracking-tighter leading-none">{selectedExercise.name}</h2>
                 </div>
              </div>

              <div className="px-8 pt-10 space-y-12 max-w-2xl mx-auto">
                 {/* Resumo Técnico */}
                 <div className="grid grid-cols-2 gap-4">
                    <TechCard icon={<Dumbbell size={16}/>} label="Equipamento" val={selectedExercise.equipment} />
                    <TechCard icon={<Hash size={16}/>} label="Musculatura Secundária" val={selectedExercise.secondaryMuscles?.join(', ') || 'N/A'} />
                 </div>

                 {/* Bio */}
                 <div className="space-y-4">
                    <h4 className="text-[11px] font-black text-zinc-600 uppercase tracking-widest italic flex items-center gap-2">
                      <Zap size={16} className="text-yellow-400" fill="currentColor" /> Bio-Descrição do Protocolo
                    </h4>
                    <p className="text-lg font-bold italic text-zinc-300 leading-relaxed uppercase tracking-tight">{selectedExercise.description}</p>
                 </div>

                 {/* Passo a Passo */}
                 <div className="space-y-6">
                    <h4 className="text-[11px] font-black text-zinc-600 uppercase tracking-widest italic flex items-center gap-2">
                       <PlayCircle size={16} className="text-emerald-500" /> Sequência de Execução
                    </h4>
                    <div className="space-y-4">
                       {selectedExercise.steps.map((step, idx) => (
                         <div key={idx} className="bg-zinc-900 border border-zinc-800 p-6 rounded-[2rem] flex gap-5">
                            <span className="text-yellow-400 font-black italic text-3xl opacity-30 leading-none">{idx + 1}</span>
                            <p className="text-sm font-bold text-zinc-200 italic uppercase tracking-tight leading-relaxed">{step}</p>
                         </div>
                       ))}
                    </div>
                 </div>

                 {/* Erros e Segurança */}
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                       <h4 className="text-[11px] font-black text-red-500 uppercase tracking-widest italic flex items-center gap-2">
                          <AlertTriangle size={16} /> Falhas Críticas
                       </h4>
                       <ul className="space-y-3">
                          {selectedExercise.commonErrors.map((err, idx) => (
                            <li key={idx} className="text-xs font-bold text-zinc-500 italic uppercase flex gap-3 items-start">
                               <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-1.5 flex-shrink-0"></div>
                               {err}
                            </li>
                          ))}
                       </ul>
                    </div>
                    <div className="space-y-4">
                       <h4 className="text-[11px] font-black text-emerald-500 uppercase tracking-widest italic flex items-center gap-2">
                          <ShieldCheck size={16} /> Dicas de Elite
                       </h4>
                       <ul className="space-y-3">
                          {selectedExercise.tips.map((tip, idx) => (
                            <li key={idx} className="text-xs font-bold text-zinc-500 italic uppercase flex gap-3 items-start">
                               <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-1.5 flex-shrink-0"></div>
                               {tip}
                            </li>
                          ))}
                       </ul>
                    </div>
                 </div>

                 {/* Botão Ação */}
                 <button 
                  onClick={() => setSelectedExercise(null)}
                  className="w-full bg-yellow-400 text-black py-8 rounded-[2.5rem] font-black italic uppercase tracking-widest text-xl shadow-2xl shadow-yellow-500/30 active:scale-95 transition-all mt-8"
                 >
                   ENTENDIDO, VOLTAR
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

const TechCard = ({ icon, label, val }: any) => (
  <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-[2rem] space-y-2">
    <div className="text-zinc-700">{icon}</div>
    <p className="text-[8px] font-black text-zinc-600 uppercase tracking-widest italic leading-none">{label}</p>
    <p className="text-sm font-black italic text-white uppercase tracking-tighter leading-none">{val}</p>
  </div>
);

export default ExerciseLibrary;
