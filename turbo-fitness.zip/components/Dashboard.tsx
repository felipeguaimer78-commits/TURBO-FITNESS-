
import React, { useState, useEffect } from 'react';
import { Activity, FoodLog, UserProfile } from '../types';
import { 
  Zap, 
  Flame, 
  Trophy,
  Activity as ActivityIcon,
  ChevronRight,
  Target,
  Watch,
  Heart,
  Footprints,
  Moon,
  Smartphone,
  ShieldCheck,
  TrendingUp,
  Battery,
  Bluetooth,
  Activity as PerformanceIcon
} from 'lucide-react';

interface DashboardProps {
  activities: Activity[];
  foodLogs: FoodLog[];
  userProfile: UserProfile;
  watchConnected: boolean;
  onConnectWatch: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ activities, foodLogs, userProfile, watchConnected, onConnectWatch }) => {
  const [heartRate, setHeartRate] = useState(72);
  const totalKm = activities.reduce((acc, curr) => acc + (curr.distance || 0), 0) / 1000;

  useEffect(() => {
    if (watchConnected) {
      const interval = setInterval(() => {
        setHeartRate(prev => Math.max(65, Math.min(85, prev + (Math.random() > 0.5 ? 1 : -1))));
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [watchConnected]);
  
  return (
    <div className="space-y-6 pb-12">
      {!watchConnected && (
        <section className="bg-yellow-400 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden group active:scale-[0.99] transition-all">
          <div className="absolute -right-10 -top-10 w-40 h-40 bg-white/10 blur-3xl rounded-full transition-transform group-hover:scale-125"></div>
          <div className="relative z-10 space-y-5">
            <h3 className="text-2xl sm:text-3xl font-black italic text-black uppercase tracking-tighter leading-none">PERFORMANCE<br/>SEM LIMITES</h3>
            <p className="text-black/80 text-[11px] sm:text-xs font-bold italic uppercase tracking-tight leading-snug">Conecte seu smartwatch e maximize sua telemetria em tempo real.</p>
            <button onClick={onConnectWatch} className="w-full bg-black text-yellow-400 py-5 rounded-2xl font-black italic uppercase tracking-[0.2em] text-[11px] active:scale-95 transition-all shadow-xl shadow-black/20">CONECTAR SMARTWATCH</button>
          </div>
        </section>
      )}

      <section className="bg-zinc-900 border border-zinc-800 rounded-[3rem] p-8 sm:p-10 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-400/5 blur-[100px] rounded-full -mr-32 -mt-32"></div>
        <div className="space-y-6">
          <div className="flex items-center gap-2.5 bg-yellow-400/10 text-yellow-400 px-4 py-1.5 rounded-full w-fit border border-yellow-400/10">
            <Zap size={12} fill="currentColor" />
            <span className="text-[9px] font-black uppercase italic tracking-widest">Sessão Telemetria</span>
          </div>
          <div className="space-y-1">
            <p className="text-zinc-600 text-[11px] font-black uppercase italic tracking-[0.3em] pl-1">Volume Semanal</p>
            <h2 className="text-6xl sm:text-7xl font-black italic tracking-tighter text-white truncate leading-none">
              {totalKm.toFixed(1)} <span className="text-xl sm:text-2xl text-zinc-700 not-italic font-bold tracking-normal">KM</span>
            </h2>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <QuickStat label="Energia Gasta" val={activities.reduce((acc, cur) => acc + (cur.caloriesBurned || 0), 0)} unit="KCAL" />
            <QuickStat label="Peso Atual" val={userProfile.currentWeight || '--'} unit="KG" />
          </div>
        </div>
      </section>

      <section className="grid grid-cols-3 gap-4">
        <BioCard label="BPM" val={watchConnected ? heartRate : '--'} color="red" />
        <BioCard label="STEPS" val="8.4K" color="yellow" />
        <BioCard label="RECOV" val="82%" color="emerald" />
      </section>

      <div className="bg-zinc-900/40 border border-zinc-800 p-7 rounded-[2.5rem] flex items-center gap-5 group hover:bg-zinc-900 transition-all cursor-pointer">
         <div className="w-14 h-14 rounded-[1.5rem] bg-yellow-400 flex items-center justify-center text-black flex-shrink-0 shadow-2xl shadow-yellow-400/10 transition-transform group-hover:rotate-6">
            <PerformanceIcon size={28} strokeWidth={3} />
         </div>
         <div className="min-w-0 flex-1">
            <h4 className="text-[9px] font-black text-zinc-600 uppercase tracking-[0.4em] italic mb-1">Análise de Elite</h4>
            <p className="text-[11px] font-bold text-zinc-300 italic truncate uppercase tracking-tight leading-snug">Otimização de queima detectada: frequência basal em redução.</p>
         </div>
         <ChevronRight size={20} className="text-zinc-800 group-hover:text-yellow-400 transition-colors" />
      </div>
    </div>
  );
};

const QuickStat = ({ label, val, unit }: any) => (
  <div className="bg-white/[0.03] border border-white/[0.06] rounded-[1.5rem] p-6 active:scale-95 transition-all">
    <p className="text-[9px] font-black text-zinc-600 uppercase italic tracking-widest mb-1.5">{label}</p>
    <p className="text-2xl font-black italic text-white truncate leading-none">
      {val}<span className="text-[11px] text-zinc-700 ml-1.5 font-bold tracking-normal">{unit}</span>
    </p>
  </div>
);

const BioCard = ({ label, val, color }: any) => (
  <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-[2rem] text-center flex flex-col items-center justify-center space-y-3 group hover:border-zinc-700 transition-all active:scale-95 shadow-xl">
    <p className="text-[8px] font-black text-zinc-600 uppercase tracking-[0.2em] italic leading-none">{label}</p>
    <p className="text-2xl font-black italic text-white truncate leading-none">{val}</p>
    <div className={`w-2 h-2 rounded-full bg-${color}-500 shadow-[0_0_10px_var(--tw-shadow-color)] shadow-${color}-500 group-hover:scale-125 transition-transform animate-pulse`}></div>
  </div>
);

export default Dashboard;
