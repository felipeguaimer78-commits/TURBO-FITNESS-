
import React, { useState, useEffect } from 'react';
import { Tab, Activity, TrainingPlan, ActivityType, FoodLog, UserProfile } from '../types';
import { CacheService } from '../services/storageService';
import Dashboard from './Dashboard';
import TrainingSection from './TrainingSection';
import Tracker from './Tracker';
import History from './History';
import Insights from './Insights';
import Nutrition from './Nutrition';
import ExerciseLibrary from './ExerciseLibrary';
import Profile from './Profile';
import { 
  LayoutDashboard, 
  Dumbbell, 
  PlayCircle, 
  Zap, 
  ArrowRight, 
  Watch, 
  TrendingUp, 
  User, 
  Mail, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  RefreshCw,
  CloudLightning
} from 'lucide-react';

// Fix: Component export added at the end of file to resolve index.tsx import error
const App: React.FC = () => {
  const [isLaunching, setIsLaunching] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [activities, setActivities] = useState<Activity[]>([]);
  const [foodLogs, setFoodLogs] = useState<FoodLog[]>([]);
  const [currentPlan, setCurrentPlan] = useState<TrainingPlan | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showTutorialStep, setShowTutorialStep] = useState<number | null>(null);
  const [watchConnected, setWatchConnected] = useState(false);

  // Carregamento IMEDIATO do Cache (Estratégia de Performance Elite)
  useEffect(() => {
    const bootstrapApp = async () => {
      setIsSyncing(true);
      
      // Recupera dados instantaneamente do cache local
      const cachedProfile = CacheService.getProfile();
      const cachedActivities = CacheService.getActivities();
      const cachedFood = CacheService.getFoodLogs();
      const cachedPlan = CacheService.getPlan();

      if (cachedProfile) setUserProfile(cachedProfile);
      if (cachedActivities) setActivities(cachedActivities);
      if (cachedFood) setFoodLogs(cachedFood);
      if (cachedPlan) setCurrentPlan(cachedPlan);

      // Simula uma verificação de integridade de nuvem
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      setIsSyncing(false);
      setIsLaunching(false);
    };
    bootstrapApp();
  }, []);

  // Persistência Ativa em Background
  useEffect(() => {
    if (userProfile) {
      CacheService.saveProfile(userProfile);
      if (userProfile.isLoggedIn && userProfile.hasSeenOnboarding && !userProfile.hasSeenTutorial && showTutorialStep === null) {
        setShowTutorialStep(0);
      }
    }
  }, [userProfile]);

  useEffect(() => {
    if (activities.length > 0) CacheService.saveActivities(activities);
  }, [activities]);

  useEffect(() => {
    if (foodLogs.length > 0) CacheService.saveFoodLogs(foodLogs);
  }, [foodLogs]);

  useEffect(() => {
    if (currentPlan) CacheService.savePlan(currentPlan);
  }, [currentPlan]);

  const saveProfile = (p: UserProfile) => {
    setUserProfile({ ...p, hasSeenOnboarding: true });
  };

  const handleLogout = () => {
    setUserProfile(null);
    localStorage.clear(); // Limpa cache no logout por segurança biométrica
  };

  if (isLaunching) return <LaunchScreen />;

  if (!userProfile || !userProfile.isLoggedIn) {
    return <AuthScreen onLogin={(p) => setUserProfile(p)} />;
  }

  if (!userProfile.hasSeenOnboarding) {
    return <Onboarding existingProfile={userProfile} onComplete={saveProfile} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard activities={activities} foodLogs={foodLogs} userProfile={userProfile} watchConnected={watchConnected} onConnectWatch={() => setWatchConnected(true)} />;
      case 'training': return <TrainingSection history={activities} dietLogs={foodLogs} onPlanUpdate={setCurrentPlan} currentPlan={currentPlan} />;
      case 'tracker': return <Tracker onComplete={(activity) => { setActivities(prev => [activity, ...prev]); setActiveTab('dashboard'); }} watchConnected={watchConnected} />;
      case 'nutrition': return <Nutrition onLog={(log) => setFoodLogs(prev => [log, ...prev])} logs={foodLogs} userProfile={userProfile} onUpdateProfile={saveProfile} />;
      case 'insights': return <Insights activities={activities} />;
      case 'library': return <ExerciseLibrary />;
      case 'history': return <History activities={activities} />;
      case 'profile': return <Profile activities={activities} userProfile={userProfile} onUpdateProfile={setUserProfile} onLogout={handleLogout} />;
      default: return <Dashboard activities={activities} foodLogs={foodLogs} userProfile={userProfile} watchConnected={watchConnected} onConnectWatch={() => setWatchConnected(true)} />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#050505] text-zinc-50 overflow-hidden font-sans">
      <header className="px-6 py-5 flex justify-between items-center border-b border-zinc-900 bg-black/60 backdrop-blur-2xl sticky top-0 z-50">
        <div className="flex flex-col min-w-0 pr-4">
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black italic tracking-tighter text-yellow-400 whitespace-nowrap">TURBO<span className="text-zinc-50 font-normal opacity-80">FITNESS</span></h1>
            {isSyncing && (
              <div className="flex items-center gap-1 bg-yellow-400/10 px-2 py-0.5 rounded-full animate-pulse">
                <CloudLightning size={10} className="text-yellow-400" />
                <span className="text-[7px] font-black uppercase text-yellow-400 tracking-tighter">Sync</span>
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <span className={`w-1.5 h-1.5 rounded-full ${isSyncing ? 'bg-yellow-400 animate-ping' : 'bg-red-500'}`}></span>
              <span className="text-[8px] uppercase tracking-[0.2em] text-zinc-500 font-black italic">
                {isSyncing ? 'Sincronizando Lab' : 'Lab Ativo'}
              </span>
            </div>
            {watchConnected && (
              <div className="flex items-center gap-1.5 bg-yellow-400/10 px-2 py-0.5 rounded-full">
                <Watch size={10} className="text-yellow-400" />
                <span className="text-[7px] uppercase tracking-widest text-yellow-400 font-black">Link</span>
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center gap-3">
           <button 
             onClick={() => setActiveTab('profile')}
             className={`relative w-11 h-11 sm:w-13 sm:h-13 rounded-full border-2 transition-all active:scale-90 overflow-hidden shadow-2xl ${activeTab === 'profile' ? 'border-yellow-400 ring-2 ring-yellow-400/20 shadow-yellow-400/10' : 'border-zinc-800'}`}
           >
             {userProfile?.photoUrl ? (
               <img src={userProfile.photoUrl} className="w-full h-full object-cover" alt="Profile" />
             ) : (
               <div className="w-full h-full bg-zinc-900 flex items-center justify-center text-zinc-600">
                 <User size={22} />
               </div>
             )}
           </button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto pb-32 no-scrollbar">
        <div className="max-w-xl mx-auto p-5 sm:p-8 animate-in fade-in duration-700">
          {renderContent()}
        </div>
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-black/95 backdrop-blur-3xl border-t border-zinc-900 z-[100] safe-bottom">
        <div className="max-w-xl mx-auto grid grid-cols-5 h-20 px-2 items-center">
          <NavButton active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<LayoutDashboard size={22} />} label="Radar" />
          <NavButton active={activeTab === 'training'} onClick={() => setActiveTab('training')} icon={<Dumbbell size={22} />} label="Planos" />
          
          <div className="relative flex items-center justify-center -top-8 h-full">
            <button 
              onClick={() => setActiveTab('tracker')}
              className={`w-18 h-18 rounded-full flex items-center justify-center shadow-2xl transition-all active:scale-90 border-4 border-[#050505] ${activeTab === 'tracker' ? 'bg-white text-black' : 'bg-yellow-400 text-black shadow-yellow-400/20'}`}
            >
              <PlayCircle size={38} fill="currentColor" />
            </button>
          </div>

          <NavButton active={activeTab === 'nutrition'} onClick={() => setActiveTab('nutrition')} icon={<Zap size={22} />} label="Macros" />
          <NavButton active={activeTab === 'insights'} onClick={() => setActiveTab('insights')} icon={<TrendingUp size={22} />} label="Status" />
        </div>
      </nav>

      {showTutorialStep !== null && (
        <VirtualAssistant tutorialStep={showTutorialStep} onNext={() => setShowTutorialStep(prev => prev !== null && prev < 5 ? prev + 1 : null)} onFinish={() => { setShowTutorialStep(null); if(userProfile) setUserProfile({...userProfile, hasSeenTutorial: true})}} />
      )}
    </div>
  );
};

const LaunchScreen = () => {
  const [statusText, setStatusText] = useState("INITIALIZING_CORE");
  
  useEffect(() => {
    const statuses = [
      "LOADING_BIOMETRIC_CACHE",
      "HYDRATING_ACTIVITY_RECORDS",
      "SYNCING_GPS_SATELLITES",
      "CONNECTING_ELITE_NETWORK",
      "READY_FOR_PERFORMANCE"
    ];
    let i = 0;
    const interval = setInterval(() => {
      if (i < statuses.length) {
        setStatusText(statuses[i]);
        i++;
      } else {
        clearInterval(interval);
      }
    }, 600);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-[2000] overflow-hidden p-8">
      <div className="absolute inset-0 pointer-events-none z-[2001] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%] opacity-20"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-yellow-500/10 via-transparent to-transparent opacity-0 animate-[pulse_4s_ease-in-out_infinite] scale-150"></div>
      
      <div className="relative flex flex-col items-center w-full max-w-sm">
        <div className="flex flex-col items-center animate-[premium-launch_4s_cubic-bezier(0.19,1,0.22,1)_forwards]">
          <div className="relative mb-12">
             <div className="absolute inset-0 text-red-500/30 translate-x-1 translate-y-0.5 blur-[2px] animate-pulse">
               <Zap size={110} />
             </div>
             <div className="absolute inset-0 text-blue-500/30 -translate-x-1 -translate-y-0.5 blur-[2px] animate-pulse">
               <Zap size={110} />
             </div>
             <Zap size={110} className="text-yellow-400 drop-shadow-[0_0_50px_rgba(250,204,21,0.7)] relative z-10" />
             <div className="absolute -inset-10 bg-yellow-400/10 blur-3xl rounded-full animate-ping"></div>
          </div>

          <h1 className="text-clamp-huge font-black italic tracking-tighter text-white uppercase text-center w-full drop-shadow-[0_0_20px_rgba(255,255,255,0.2)]">
            TURBO<br/><span className="text-yellow-400">FITNESS</span>
          </h1>
          
          <div className="mt-12 flex flex-col items-center gap-4">
            <div className="flex gap-4">
              <div className="w-2.5 h-2.5 bg-yellow-400 rounded-full animate-bounce shadow-lg shadow-yellow-500/50" style={{animationDelay: '0ms'}}></div>
              <div className="w-2.5 h-2.5 bg-yellow-400 rounded-full animate-bounce shadow-lg shadow-yellow-500/50" style={{animationDelay: '200ms'}}></div>
              <div className="w-2.5 h-2.5 bg-yellow-400 rounded-full animate-bounce shadow-lg shadow-yellow-500/50" style={{animationDelay: '400ms'}}></div>
            </div>
            
            <div className="flex items-center gap-3 mt-4">
              <RefreshCw size={12} className="text-yellow-400/60 animate-spin" />
              <span className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.4em] italic opacity-80 min-w-[200px] text-center">
                {statusText}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-12 left-0 right-0 flex flex-col items-center opacity-30 animate-pulse">
        <p className="text-[8px] font-black text-zinc-700 uppercase tracking-[0.8em] italic">Elite Cache Architecture Activated</p>
      </div>

      <style>{`
        @keyframes premium-launch {
          0% { transform: scale(0.3) translateY(40px); opacity: 0; filter: blur(40px) brightness(2); }
          15% { opacity: 1; filter: blur(20px) brightness(1.5); }
          40% { filter: blur(0px) brightness(1); }
          100% { transform: scale(1) translateY(0px); opacity: 1; filter: blur(0px) brightness(1); }
        }
      `}</style>
    </div>
  );
};

const AuthScreen = ({ onLogin }: { onLogin: (p: UserProfile) => void }) => {
  const [emailMode, setEmailMode] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    onLogin({
      name: email.split('@')[0].toUpperCase(),
      email: email,
      currentWeight: 0,
      targetWeight: 0,
      goalType: 'LOSE',
      isLoggedIn: true,
      hasSeenOnboarding: false,
      hasSeenTutorial: false
    });
    setIsLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-[#050505] flex flex-col items-center justify-center p-8 z-[300] animate-in fade-in duration-1000 overflow-y-auto no-scrollbar">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-yellow-500/5 via-transparent to-transparent"></div>
      
      <div className="relative text-center mb-12 sm:mb-20 flex flex-col items-center w-full">
        <div className="w-20 h-20 sm:w-24 sm:h-24 bg-yellow-400 rounded-[2rem] flex items-center justify-center mb-6 shadow-2xl shadow-yellow-400/10">
           <Zap size={40} className="text-black" />
        </div>
        <h1 className="text-clamp-large font-black italic tracking-tighter text-white uppercase">TURBO<span className="text-yellow-400">FITNESS</span></h1>
        <p className="text-zinc-600 font-black uppercase tracking-[0.3em] text-[10px] italic mt-3">Elite Performance Labs OS</p>
      </div>

      <div className="w-full max-sm space-y-6 relative z-10">
        {!emailMode ? (
          <div className="space-y-4">
            <button 
              onClick={() => { setIsLoading(true); setTimeout(() => onLogin({ name: 'Atleta Turbo', isLoggedIn: true, currentWeight: 0, targetWeight: 0, goalType: 'LOSE', hasSeenOnboarding: false, hasSeenTutorial: false }), 1000); }} 
              disabled={isLoading}
              className="w-full h-18 sm:h-20 bg-white text-black rounded-[2rem] font-black italic uppercase tracking-widest flex items-center justify-center gap-4 active:scale-95 transition-all text-sm px-6 shadow-2xl"
            >
              <svg className="w-6 h-6 flex-shrink-0" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
              <span className="truncate">Login com Google</span>
            </button>
            
            <button 
              onClick={() => setEmailMode(true)} 
              className="w-full h-18 sm:h-20 bg-zinc-900 text-white rounded-[2rem] font-black italic uppercase tracking-widest flex items-center justify-center gap-4 border border-zinc-800 active:scale-95 transition-all text-sm px-6 shadow-xl"
            >
              <Mail size={22} className="flex-shrink-0" /> <span className="truncate">Login com Email</span>
            </button>
          </div>
        ) : (
          <form onSubmit={handleEmailLogin} className="space-y-5 animate-in zoom-in-95">
             <input 
               type="email" 
               required
               placeholder="SEU@EMAIL.COM" 
               value={email}
               onChange={(e) => setEmail(e.target.value)}
               className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-[2rem] p-6 font-black italic text-center outline-none focus:border-yellow-400 text-white text-base shadow-inner" 
             />
             <div className="relative">
               <input 
                 type={showPassword ? "text" : "password"} 
                 required
                 placeholder="CÓDIGO DE ACESSO" 
                 value={password}
                 onChange={(e) => setPassword(e.target.value)}
                 className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-[2rem] p-6 font-black italic text-center outline-none focus:border-yellow-400 text-white text-base shadow-inner" 
               />
               <button 
                 type="button" 
                 onClick={() => setShowPassword(!showPassword)}
                 className="absolute right-6 top-1/2 -translate-y-1/2 text-zinc-600"
               >
                 {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
               </button>
             </div>
             <button type="submit" className="w-full h-18 bg-yellow-400 text-black rounded-[2rem] font-black italic uppercase tracking-widest active:scale-95 transition-all text-base shadow-2xl">INICIAR SEQUÊNCIA</button>
             <button type="button" onClick={() => setEmailMode(false)} className="w-full text-[11px] font-black text-zinc-600 uppercase italic tracking-widest hover:text-zinc-400 py-2">Voltar para Opções</button>
          </form>
        )}
      </div>
    </div>
  );
};

const Onboarding = ({ existingProfile, onComplete }: { existingProfile: UserProfile, onComplete: (p: UserProfile) => void }) => {
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState<UserProfile>(existingProfile);

  const next = () => { if (step < 2) setStep(step + 1); else onComplete(profile); };
  
  const skip = () => {
    if (step === 1) setProfile({ ...profile, currentWeight: 0 });
    if (step === 2) setProfile({ ...profile, targetWeight: 0 });
    next();
  };

  return (
    <div className="fixed inset-0 bg-black z-[400] p-10 flex flex-col justify-between overflow-y-auto no-scrollbar">
      <div className="space-y-6 mt-12">
        <div className="flex items-center gap-4">
           <div className="w-16 h-1.5 bg-yellow-400 rounded-full shadow-[0_0_15px_rgba(250,204,21,0.3)]"></div>
           <span className="text-[11px] font-black text-yellow-400 uppercase italic tracking-widest">Protocolo {step + 1}/3</span>
        </div>
        <h1 className="text-clamp-large font-black italic text-white tracking-tighter uppercase leading-none">RECALIBRAR<br/><span className="text-yellow-400">BIOMETRIA</span></h1>
      </div>
      
      <div className="flex-1 flex flex-col justify-center py-12">
        {step === 0 && (
          <div className="space-y-4">
            <p className="text-xl font-black italic uppercase text-zinc-600 mb-2">Objetivo de Performance:</p>
            {['LOSE', 'MAINTAIN', 'GAIN'].map((g) => (
              <button key={g} onClick={() => setProfile({...profile, goalType: g as any})} className={`w-full p-8 rounded-[2rem] border-2 font-black italic uppercase text-left transition-all text-base shadow-lg ${profile.goalType === g ? 'bg-yellow-400 border-yellow-400 text-black shadow-yellow-400/20' : 'border-zinc-800 text-zinc-600 hover:border-zinc-700'}`}>
                {g === 'LOSE' ? 'Queimar Gordura' : g === 'GAIN' ? 'Ganhar Massa' : 'Manter Saúde'}
              </button>
            ))}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-6">
            <div className="flex justify-between items-center px-2">
              <p className="text-xl font-black italic uppercase text-zinc-600">Peso Atual:</p>
              <button onClick={skip} className="text-[11px] font-black text-zinc-500 uppercase italic underline decoration-zinc-800">Pular</button>
            </div>
            <div className="relative">
              <input type="number" autoFocus className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-[2.5rem] p-12 text-7xl font-black italic outline-none focus:border-yellow-400 text-white shadow-inner" placeholder="00" onChange={(e) => setProfile({...profile, currentWeight: Number(e.target.value)})} />
              <span className="absolute right-10 top-1/2 -translate-y-1/2 text-3xl font-black italic text-zinc-700">KG</span>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div className="flex justify-between items-center px-2">
              <p className="text-xl font-black italic uppercase text-zinc-600">Meta de Peso:</p>
              <button onClick={skip} className="text-[11px] font-black text-zinc-500 uppercase italic underline decoration-zinc-800">Pular</button>
            </div>
            <div className="relative">
              <input type="number" autoFocus className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-[2.5rem] p-12 text-7xl font-black italic outline-none focus:border-yellow-400 text-white shadow-inner" placeholder="00" onChange={(e) => setProfile({...profile, targetWeight: Number(e.target.value)})} />
              <span className="absolute right-10 top-1/2 -translate-y-1/2 text-3xl font-black italic text-zinc-700">KG</span>
            </div>
          </div>
        )}
      </div>

      <div className="mt-8 flex gap-4">
        <button 
          onClick={next} 
          className="flex-1 bg-yellow-400 text-black py-7 rounded-[2.5rem] font-black italic uppercase tracking-widest shadow-2xl active:scale-95 transition-all"
        >
          CONTINUAR PROTOCOLO
        </button>
      </div>
    </div>
  );
};

// Fix: Missing NavButton component added
const NavButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center justify-center gap-1 transition-all active:scale-90 ${active ? 'text-yellow-400' : 'text-zinc-500'}`}
  >
    {icon}
    <span className="text-[9px] font-black uppercase italic tracking-widest">{label}</span>
  </button>
);

// Fix: Missing VirtualAssistant component added
const VirtualAssistant: React.FC<{ tutorialStep: number; onNext: () => void; onFinish: () => void }> = ({ tutorialStep, onNext, onFinish }) => {
  const steps = [
    { title: "RADAR DE ELITE", desc: "Monitore sua telemetria basal e volume semanal em tempo real." },
    { title: "PLANOS ADAPTATIVOS", desc: "A IA Turbo recalibra seus treinos baseada no seu desempenho real." },
    { title: "TRACKER SINCRO", desc: "Registre atividades com GPS e capture biometria visual de exercícios." },
    { title: "MACROS LAB", desc: "Identificação instantânea de alimentos via câmera ou texto." },
    { title: "STATUS DE PERFORMANCE", desc: "Visualize sua fadiga, fitness e previsões de recordes." }
  ];

  return (
    <div className="fixed inset-0 z-[1000] bg-black/80 backdrop-blur-xl flex items-center justify-center p-8 animate-in fade-in duration-500">
      <div className="bg-zinc-900 border-2 border-yellow-400 p-10 rounded-[3rem] max-w-sm w-full space-y-8 shadow-[0_0_100px_rgba(250,204,21,0.15)] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-400/5 blur-3xl rounded-full"></div>
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-yellow-400 rounded-2xl flex items-center justify-center shadow-lg">
            <Zap size={24} className="text-black" fill="currentColor" />
          </div>
          <h3 className="text-2xl font-black italic text-white uppercase tracking-tighter">TURBO<span className="text-yellow-400">GUIDE</span></h3>
        </div>
        <div className="space-y-3">
          <h4 className="text-xs font-black text-yellow-400 uppercase tracking-[0.3em] italic">{steps[tutorialStep]?.title}</h4>
          <p className="text-sm font-bold text-zinc-400 italic uppercase leading-relaxed tracking-tight">{steps[tutorialStep]?.desc}</p>
        </div>
        <div className="flex justify-between items-center pt-4">
          <div className="flex gap-2">
            {steps.map((_, i) => (
              <div key={i} className={`w-2 h-2 rounded-full transition-all duration-500 ${i === tutorialStep ? 'bg-yellow-400 w-6' : 'bg-zinc-800'}`} />
            ))}
          </div>
          <button 
            onClick={tutorialStep < steps.length - 1 ? onNext : onFinish}
            className="bg-yellow-400 text-black px-8 py-4 rounded-2xl font-black italic uppercase text-[10px] tracking-widest active:scale-95 transition-all shadow-xl shadow-yellow-400/10"
          >
            {tutorialStep < steps.length - 1 ? 'PRÓXIMO' : 'ENTENDIDO'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default App;
