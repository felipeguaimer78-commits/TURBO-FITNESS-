
import React, { useState } from 'react';
import { Activity, TrainingPlan, FoodLog } from '../types';
import { getTrainingPlan } from '../services/geminiService';
import { Sparkles, CheckCircle2, Circle, ChevronRight, Loader2 } from 'lucide-react';

interface TrainingSectionProps {
  history: Activity[];
  dietLogs: FoodLog[];
  onPlanUpdate: (plan: TrainingPlan) => void;
  currentPlan: TrainingPlan | null;
}

const TrainingSection: React.FC<TrainingSectionProps> = ({ history, dietLogs, onPlanUpdate, currentPlan }) => {
  const [loading, setLoading] = useState(false);
  const [goal, setGoal] = useState('Correr minha primeira maratona sub-4h');

  const generatePlan = async () => {
    setLoading(true);
    try {
      const plan = await getTrainingPlan(goal, history, dietLogs);
      onPlanUpdate(plan);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-3xl font-black italic uppercase tracking-tighter text-white">Planos de Treino</h2>
        <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest italic">Adaptados dinamicamente pelos nossos personais.</p>
      </header>

      {!currentPlan ? (
        <div className="bg-zinc-900 border border-zinc-800 rounded-[2.5rem] p-8 space-y-6 shadow-2xl">
          <div className="space-y-3">
            <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic ml-2">Qual seu objetivo de elite?</label>
            <input 
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              className="w-full bg-black border border-zinc-800 rounded-3xl p-5 text-sm font-bold focus:border-yellow-400 outline-none transition-all text-white"
              placeholder="Ex: 5km em 20 minutos"
            />
          </div>
          
          <button 
            disabled={loading}
            onClick={generatePlan}
            className="w-full bg-yellow-400 text-black font-black py-5 rounded-3xl flex items-center justify-center gap-3 hover:bg-yellow-300 transition-all active:scale-95 shadow-xl uppercase italic tracking-widest disabled:opacity-50"
          >
            {loading ? <Loader2 size={24} className="animate-spin" /> : <Sparkles size={24} />}
            {loading ? 'Sincronizando Dados...' : 'Gerar Plano TURBO FITNESS'}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex justify-between items-center px-2">
             <h3 className="text-lg font-black italic uppercase text-yellow-400">{currentPlan.goal}</h3>
             <button onClick={() => onPlanUpdate(null)} className="text-[10px] font-black text-zinc-600 uppercase italic underline decoration-zinc-800">Mudar Alvo</button>
          </div>

          <div className="space-y-4">
            {currentPlan.workouts.map((workout, idx) => (
              <div key={idx} className="bg-zinc-900/50 border border-zinc-800 rounded-[2rem] p-5 flex items-center gap-5 hover:border-zinc-700 transition-all group cursor-pointer active:scale-98">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg ${workout.intensity === 'High' ? 'bg-orange-500/20 text-orange-400' : 'bg-zinc-800 text-zinc-600'}`}>
                  {idx === 0 ? <CheckCircle2 size={24} className="text-yellow-400" /> : <Circle size={24} />}
                </div>
                <div className="flex-1">
                  <h4 className="font-black italic text-sm text-white group-hover:text-yellow-400 transition-colors uppercase tracking-tight">Dia {workout.day}: {workout.title}</h4>
                  <p className="text-[11px] text-zinc-500 font-bold italic line-clamp-1">{workout.description}</p>
                </div>
                <div className="text-right">
                  <p className="text-base font-black italic text-white">{workout.durationMinutes}m</p>
                  <p className="text-[9px] text-zinc-600 font-black uppercase italic tracking-tighter">{workout.intensity}</p>
                </div>
                <ChevronRight size={18} className="text-zinc-800" />
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="p-6 bg-yellow-400/5 border border-yellow-400/20 rounded-[2rem] space-y-3">
        <h4 className="text-yellow-400 text-[10px] font-black flex items-center gap-2 uppercase tracking-[0.2em] italic">
          <Sparkles size={14} />
          MOTOR DE TREINO TURBO FITNESS
        </h4>
        <p className="text-[11px] text-zinc-500 font-bold leading-relaxed italic uppercase tracking-tight">
          Nosso motor inteligente analisa seu esforço percebido e volume calórico para ajustar as próximas sessões. Se você exceder hoje, o TURBO FITNESS recalibra sua recuperação automaticamente.
        </p>
      </div>
    </div>
  );
};

export default TrainingSection;
