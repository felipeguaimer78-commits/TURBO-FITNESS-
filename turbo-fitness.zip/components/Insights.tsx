
import React, { useState, useEffect } from 'react';
import { Activity, PerformanceStats } from '../types';
import { getPerformanceInsights } from '../services/geminiService';
import { TrendingUp, Battery, Heart, Trophy, Info, Zap } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from 'recharts';

interface InsightsProps {
  activities: Activity[];
}

const Insights: React.FC<InsightsProps> = ({ activities }) => {
  const [stats, setStats] = useState<PerformanceStats | null>(null);

  useEffect(() => {
    const load = async () => {
      const s = await getPerformanceInsights(activities);
      setStats(s);
    };
    load();
  }, [activities]);

  if (!stats) return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <Zap size={40} className="text-zinc-800 animate-spin" />
      <p className="text-[10px] font-black text-zinc-700 uppercase italic tracking-widest">Processando Telemetria...</p>
    </div>
  );

  const metricsData = [
    { name: 'Fitness', val: stats.fitness, color: '#facc15' },
    { name: 'Fadiga', val: stats.fatigue, color: '#f97316' },
    { name: 'Recuperação', val: stats.recovery, color: '#3b82f6' },
  ];

  return (
    <div className="space-y-6 pb-12">
      <header>
        <h2 className="text-3xl font-black italic text-yellow-400 uppercase tracking-tighter leading-none">Análise<br/>Performance</h2>
        <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest italic mt-1">Sincronizado com o Sistema Turbo.</p>
      </header>

      <section className="bg-zinc-900 border border-zinc-800 rounded-[2.5rem] p-8 shadow-2xl overflow-hidden relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-400/5 blur-3xl rounded-full"></div>
        <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em] mb-8 italic">Status Biomagnético</h3>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={metricsData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#3f3f46', fontWeight: 900, textTransform: 'uppercase' }} />
              <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#27272a' }} />
              <Tooltip cursor={{ fill: '#18181b' }} contentStyle={{ backgroundColor: '#000', border: '1px solid #27272a', borderRadius: '1rem', fontSize: '10px', color: '#fff' }} />
              <Bar dataKey="val" radius={[12, 12, 0, 0]} barSize={45}>
                {metricsData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-zinc-900 border border-zinc-800 rounded-[2rem] p-6 shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <Battery size={48} className="text-yellow-400" />
          </div>
          <div className="flex items-center gap-2 mb-3 text-yellow-400">
            <Battery size={16} strokeWidth={3} />
            <span className="text-[9px] font-black uppercase italic tracking-widest">Readiness</span>
          </div>
          <p className="text-2xl font-black italic text-white uppercase tracking-tighter leading-none">POWER UP</p>
          <p className="text-[9px] text-zinc-600 mt-2 font-black uppercase italic tracking-tight">Nível de prontidão em {stats.recovery}%</p>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded-[2rem] p-6 shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <Heart size={48} className="text-orange-500" />
          </div>
          <div className="flex items-center gap-2 mb-3 text-orange-500">
            <Heart size={16} strokeWidth={3} />
            <span className="text-[9px] font-black uppercase italic tracking-widest">Stress Acumulado</span>
          </div>
          <p className="text-2xl font-black italic text-white uppercase tracking-tighter leading-none">{stats.fatigue * 15}</p>
          <p className="text-[9px] text-zinc-600 mt-2 font-black uppercase italic tracking-tight">Zone: High Performance</p>
        </div>
      </div>

      <section className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <h3 className="text-sm font-black italic uppercase text-white tracking-tighter flex items-center gap-2">
            <Trophy size={18} className="text-yellow-400" /> Previsões de Recorde
          </h3>
          <Info size={16} className="text-zinc-800" />
        </div>
        <div className="space-y-3">
          {Object.entries(stats.predictedTimes).map(([dist, time]) => (
            <div key={dist} className="bg-zinc-900/40 border border-zinc-800 rounded-[2rem] p-5 flex justify-between items-center group hover:border-zinc-700 transition-all active:scale-98">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-black border border-zinc-800 flex items-center justify-center text-zinc-600 group-hover:text-yellow-400 transition-colors">
                  <Trophy size={20} />
                </div>
                <span className="font-black italic text-sm text-zinc-400 uppercase tracking-tight">{dist.replace('HalfMarathon', 'Meia Maratona')}</span>
              </div>
              <span className="font-black text-yellow-400 text-2xl italic tracking-tighter tabular-nums">{time}</span>
            </div>
          ))}
        </div>
      </section>

      <div className="bg-gradient-to-r from-yellow-400/10 to-transparent p-6 rounded-[2rem] border border-yellow-400/20 shadow-2xl">
        <p className="text-[11px] text-zinc-300 font-bold italic leading-relaxed uppercase tracking-tight">
          <strong className="text-yellow-400">PROJEÇÃO TURBO:</strong> SE VOCÊ MANTER A CONSISTÊNCIA DE {activities.length} SESSÕES/MÊS, SUA VELOCIDADE LIMIAR AUMENTARÁ EM 8% NOS PRÓXIMOS 21 DIAS.
        </p>
      </div>
    </div>
  );
};

export default Insights;
