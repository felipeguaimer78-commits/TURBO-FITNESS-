
import React, { useState, useEffect, useRef } from 'react';
import { Activity, ActivityType, GymLogEntry, GymSet, ExerciseDefinition, GPSPoint } from '../types';
import { playAudioFeedback } from '../services/geminiService';
import { 
  X, Pause, Play, Square, MapPin, Camera, Bike, Footprints, 
  Dumbbell, Trophy, Plus, Trash2, Check, Watch, Clock, Heart, 
  Zap, Share2, ArrowRight, Activity as ActivityIcon, Info, ShieldCheck,
  ChevronUp, ChevronDown, Image as ImageIcon, Share, RotateCcw,
  Loader2, Download, Award, Target
} from 'lucide-react';
import { MOCK_EXERCISES } from './ExerciseLibrary';

declare const L: any;

interface TrackerProps {
  onComplete: (activity: Activity) => void;
  watchConnected?: boolean;
}

const Tracker: React.FC<TrackerProps> = ({ onComplete, watchConnected = false }) => {
  const [mode, setMode] = useState<ActivityType | null>(null);
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [distance, setDistance] = useState(0); 
  const [photo, setPhoto] = useState<string | null>(null);
  const [gymLogs, setGymLogs] = useState<GymLogEntry[]>([]);
  const [showExPicker, setShowExPicker] = useState(false);
  const [gpsPath, setGpsPath] = useState<GPSPoint[]>([]);
  const [showSummary, setShowSummary] = useState(false);
  const [heartRate, setHeartRate] = useState(72);
  const [lastAnnouncedKm, setLastAnnouncedKm] = useState(0);
  const [capturingExerciseIdx, setCapturingExerciseIdx] = useState<number | null>(null);
  const [currentCapturePreview, setCurrentCapturePreview] = useState<string | null>(null);
  const [isGeneratingShare, setIsGeneratingShare] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const watchIdRef = useRef<number | null>(null);
  const mapInstanceRef = useRef<any>(null);
  const polylineRef = useRef<any>(null);
  const markerRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const isMovementType = mode && [ActivityType.RUN, ActivityType.CYCLE, ActivityType.WALK].includes(mode);

  // Monitora abertura do modal de foto para ligar a câmera
  useEffect(() => {
    if (capturingExerciseIdx !== null) {
      startCamera();
    } else if (!isActive && !showSummary) {
      stopCamera();
    }
  }, [capturingExerciseIdx]);

  useEffect(() => {
    if (isMovementType && isActive && !isPaused) {
      const currentKm = Math.floor(distance / 1000);
      if (currentKm > lastAnnouncedKm) {
        playAudioFeedback(`Km ${currentKm} completo.`);
        setLastAnnouncedKm(currentKm);
      }
    }
  }, [distance, lastAnnouncedKm, isActive, isPaused, isMovementType]);

  useEffect(() => {
    if (isMovementType && !showSummary) {
      const initMap = () => {
        const container = document.getElementById('interactive-map');
        if (!container || mapInstanceRef.current) return;
        mapInstanceRef.current = L.map('interactive-map', { 
          zoomControl: false, 
          attributionControl: false,
          minZoom: 15,
          maxZoom: 18,
          dragging: true,
          scrollWheelZoom: false,
          doubleClickZoom: false,
          boxZoom: false
        }).setView([0, 0], 17);
        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png').addTo(mapInstanceRef.current);
        polylineRef.current = L.polyline([], { color: '#facc15', weight: 6, opacity: 0.9 }).addTo(mapInstanceRef.current);
        markerRef.current = L.circleMarker([0, 0], { radius: 8, fillColor: '#facc15', color: '#000', weight: 3, fillOpacity: 1 }).addTo(mapInstanceRef.current);
      };
      const timer = setTimeout(initMap, 200);
      return () => { clearTimeout(timer); if (mapInstanceRef.current) mapInstanceRef.current.remove(); mapInstanceRef.current = null; };
    }
  }, [mode, showSummary, isMovementType]);

  useEffect(() => {
    let interval: number;
    if (isActive && !isPaused && !showSummary) {
      interval = window.setInterval(() => {
        setSeconds(s => s + 1);
        if (watchConnected) {
          setHeartRate(prev => Math.max(70, Math.min(190, prev + (Math.random() > 0.5 ? 1 : -1))));
        }
      }, 1000);

      if (isMovementType && 'geolocation' in navigator) {
        watchIdRef.current = navigator.geolocation.watchPosition((pos) => {
          const pt = { lat: pos.coords.latitude, lng: pos.coords.longitude, timestamp: pos.timestamp };
          setGpsPath(prev => {
            if (prev.length > 0) {
              const lastPt = prev[prev.length - 1];
              const R = 6371000;
              const dLat = (pt.lat - lastPt.lat) * Math.PI / 180;
              const dLon = (pt.lng - lastPt.lng) * Math.PI / 180;
              const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                        Math.cos(lastPt.lat * Math.PI / 180) * Math.cos(pt.lat * Math.PI / 180) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);
              const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
              const d = R * c;
              
              if (d > 2) {
                setDistance(cur => cur + d);
              }
            }
            if (mapInstanceRef.current) {
              const l = [pt.lat, pt.lng];
              polylineRef.current.addLatLng(l);
              markerRef.current.setLatLng(l);
              mapInstanceRef.current.panTo(l);
            }
            return [...prev, pt];
          });
        }, (error) => console.error("GPS Error:", error), { enableHighAccuracy: true });
      }
    }
    return () => { 
      if (interval) clearInterval(interval); 
      if (watchIdRef.current !== null) navigator.geolocation.clearWatch(watchIdRef.current); 
    };
  }, [isActive, isPaused, mode, showSummary, watchConnected, isMovementType]);

  const startCamera = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      streamRef.current = s;
      if (videoRef.current) videoRef.current.srcObject = s;
    } catch (e) {
      console.error("Erro ao acessar câmera:", e);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
  };

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      canvasRef.current.width = videoRef.current.videoWidth;
      canvasRef.current.height = videoRef.current.videoHeight;
      ctx?.drawImage(videoRef.current, 0, 0);
      const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.85);
      
      if (capturingExerciseIdx !== null) {
        setCurrentCapturePreview(dataUrl);
      } else {
        setPhoto(dataUrl);
      }
    }
  };

  const confirmCapture = () => {
    if (capturingExerciseIdx !== null && currentCapturePreview) {
      const newLogs = [...gymLogs];
      newLogs[capturingExerciseIdx].photoUrl = currentCapturePreview;
      setGymLogs(newLogs);
      setCurrentCapturePreview(null);
      setCapturingExerciseIdx(null);
      stopCamera();
    }
  };

  const discardCapture = () => {
    setCurrentCapturePreview(null);
  };

  const finish = () => {
    stopCamera();
    setShowSummary(true);
  };

  const generateShareImage = async (): Promise<File | string | null> => {
    const canvas = document.createElement('canvas');
    canvas.width = 1080;
    canvas.height = 1350; 
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    // 1. Draw Background
    if (photo) {
      const img = new Image();
      img.src = photo;
      await new Promise(resolve => img.onload = resolve);
      const scale = Math.max(canvas.width / img.width, canvas.height / img.height);
      const x = (canvas.width - img.width * scale) / 2;
      const y = (canvas.height - img.height * scale) / 2;
      ctx.drawImage(img, x, y, img.width * scale, img.height * scale);
    } else {
      ctx.fillStyle = '#050505';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    // 2. Overlays
    const bottomGrad = ctx.createLinearGradient(0, canvas.height * 0.5, 0, canvas.height);
    bottomGrad.addColorStop(0, 'rgba(0,0,0,0)');
    bottomGrad.addColorStop(1, 'rgba(0,0,0,0.95)');
    ctx.fillStyle = bottomGrad;
    ctx.fillRect(0, canvas.height * 0.5, canvas.width, canvas.height * 0.5);

    const topGrad = ctx.createLinearGradient(0, 0, 0, 400);
    topGrad.addColorStop(0, 'rgba(0,0,0,0.85)');
    topGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = topGrad;
    ctx.fillRect(0, 0, canvas.width, 400);

    // 3. Branding
    ctx.fillStyle = '#facc15';
    ctx.font = 'italic 900 72px Inter, sans-serif';
    ctx.letterSpacing = '-4px';
    ctx.fillText('TURBO', 80, 130);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'italic 300 72px Inter, sans-serif';
    ctx.fillText('FITNESS', 340, 130);

    ctx.textAlign = 'right';
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.font = 'italic 900 24px Inter, sans-serif';
    ctx.letterSpacing = '6px';
    ctx.fillText(new Date().toLocaleDateString('pt-BR').toUpperCase(), 1000, 130);

    // 4. Metrics Grid
    const distKm = (distance / 1000).toFixed(2);
    const timeFormatted = `${Math.floor(seconds/60)}:${(seconds%60).toString().padStart(2,'0')}`;
    
    ctx.textAlign = 'left';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'italic 900 240px Inter, sans-serif';
    ctx.letterSpacing = '-14px';
    const mainVal = isMovementType ? distKm : gymLogs.length.toString();
    const mainLabel = isMovementType ? 'KM' : 'EXERCÍCIOS';
    ctx.fillText(mainVal, 80, 1150);
    
    ctx.fillStyle = '#facc15';
    ctx.font = 'italic 900 36px Inter, sans-serif';
    ctx.letterSpacing = '8px';
    ctx.fillText(mainLabel, 90, 1200);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'italic 900 100px Inter, sans-serif';
    ctx.letterSpacing = '-4px';
    ctx.fillText(timeFormatted, 1000, 1100);
    
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.font = 'italic 900 24px Inter, sans-serif';
    ctx.letterSpacing = '4px';
    ctx.fillText('DURAÇÃO TOTAL', 1000, 1140);

    const secondaryVal = isMovementType ? 'MODO ELITE' : gymLogs.reduce((acc, l) => acc + l.sets.length, 0).toString() + ' SÉRIES';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'italic 900 60px Inter, sans-serif';
    ctx.fillText(secondaryVal, 1000, 1220);

    // 5. Signature
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(255,255,255,0.2)';
    ctx.font = '900 16px Inter, sans-serif';
    ctx.letterSpacing = '12px';
    ctx.fillText('POWERED BY TURBO FITNESS LABS', 540, 1310);

    return new Promise((resolve) => {
      canvas.toBlob((blob) => {
        if (!blob) return resolve(null);
        const file = new File([blob], `turbo-performance-${Date.now()}.png`, { type: 'image/png' });
        resolve(file);
      }, 'image/png', 1.0);
    });
  };

  const downloadImage = async () => {
    setIsGeneratingShare(true);
    try {
      const fileOrUrl = await generateShareImage();
      if (!fileOrUrl) return;
      
      const url = URL.createObjectURL(fileOrUrl as Blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `TurboFitness_Session_${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Download failed', e);
    } finally {
      setIsGeneratingShare(false);
    }
  };

  const handleShare = async () => {
    setIsGeneratingShare(true);
    try {
      const fileOrUrl = await generateShareImage();
      if (!fileOrUrl) return;

      const file = fileOrUrl as File;
      const distKm = (distance / 1000).toFixed(2);
      const timeFormatted = `${Math.floor(seconds/60)}:${(seconds%60).toString().padStart(2,'0')}`;
      
      const shareData = {
        title: 'TURBO FITNESS PERFORMANCE',
        text: `Protocolo concluído: ${isMovementType ? `${distKm} KM` : `${gymLogs.length} EX`} em ${timeFormatted}. #TurboFitness`,
        files: [file]
      };

      if (navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        await downloadImage();
      }
    } catch (e: any) {
      if (e.name !== 'AbortError') {
        console.warn('Share system unavailable, triggering fallback download.', e);
        await downloadImage();
      }
    } finally {
      setIsGeneratingShare(false);
    }
  };

  if (!mode) return (
    <div className="fixed inset-0 z-[100] bg-black p-6 flex flex-col justify-center gap-6 animate-in fade-in">
      <div className="text-center mb-8">
         <h2 className="text-clamp-large font-black italic text-yellow-400 tracking-tighter uppercase leading-[0.9]">INICIAR<br/>PROTOCOL</h2>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <ModeBtn icon={<Footprints size={32}/>} label="Corrida" onClick={() => {setMode(ActivityType.RUN); setIsActive(true); }} />
        <ModeBtn icon={<Bike size={32}/>} label="Pedal" onClick={() => {setMode(ActivityType.CYCLE); setIsActive(true); }} />
        <ModeBtn icon={<Dumbbell size={32}/>} label="Gym" onClick={() => {setMode(ActivityType.GYM); setIsActive(true); }} />
        <ModeBtn icon={<MapPin size={32}/>} label="Caminhada" onClick={() => {setMode(ActivityType.WALK); setIsActive(true); }} />
      </div>
    </div>
  );

  if (showSummary) {
    const distKm = (distance / 1000).toFixed(2);
    const timeFormatted = `${Math.floor(seconds/60)}:${(seconds%60).toString().padStart(2,'0')}`;

    return (
      <div className="fixed inset-0 z-[500] bg-[#050505] flex flex-col p-6 animate-in zoom-in-95 duration-500 overflow-y-auto no-scrollbar">
        <div className="max-w-md mx-auto w-full space-y-6 py-6">
           <div className="flex justify-between items-start">
             <div className="flex-1">
               <div className="flex items-center gap-2 mb-2">
                 <div className="w-5 h-5 bg-yellow-400 rounded-lg flex items-center justify-center">
                    <Award size={12} className="text-black" strokeWidth={3} />
                 </div>
                 <p className="text-[10px] font-black text-zinc-500 uppercase italic tracking-[0.4em]">SESSÃO DE ELITE</p>
               </div>
               <h2 className="text-clamp-large font-black italic text-white uppercase tracking-tighter leading-none text-left">PROTOCOL<br/><span className="text-yellow-400">COMPLETE</span></h2>
             </div>
             
             <div className="flex gap-2">
                <button 
                  onClick={downloadImage}
                  disabled={isGeneratingShare}
                  className="p-6 bg-zinc-900 border border-zinc-800 rounded-[2rem] text-zinc-400 hover:text-white transition-all active:scale-90"
                  title="Salvar Imagem"
                >
                  <Download size={24} />
                </button>
                <button 
                  onClick={handleShare}
                  disabled={isGeneratingShare}
                  className="relative group p-6 bg-zinc-900 border border-zinc-800 rounded-[2rem] text-yellow-400 shadow-[0_0_40px_rgba(0,0,0,0.5)] active:scale-90 transition-all hover:bg-zinc-800 disabled:opacity-50"
                  title="Compartilhar"
                >
                  {isGeneratingShare ? <Loader2 size={24} className="animate-spin" /> : <Share2 size={24} strokeWidth={3} className="group-hover:rotate-12 transition-transform" />}
                  {!isGeneratingShare && <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping"></div>}
                </button>
             </div>
           </div>
           
           <div className="relative rounded-[3.5rem] overflow-hidden aspect-[4/5] bg-zinc-900 border border-zinc-800 shadow-2xl group">
              {photo ? (
                <img src={photo} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2000ms]" />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center gap-6 bg-gradient-to-b from-zinc-800 to-black">
                   <div className="w-24 h-24 bg-yellow-400/10 rounded-full flex items-center justify-center border border-yellow-400/20 shadow-[0_0_100px_rgba(250,204,21,0.1)]">
                      <Trophy size={64} className="text-yellow-400" />
                   </div>
                   <p className="text-2xl font-black italic uppercase text-white tracking-tighter">TURBO PERFORMANCE ACTIVATED</p>
                </div>
              )}
              
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/60 pointer-events-none"></div>
              
              <div className="absolute top-8 left-8 flex flex-col gap-1">
                 <p className="text-xl font-black italic text-white leading-none tracking-tighter">TURBO<span className="text-yellow-400">FITNESS</span></p>
                 <p className="text-[9px] font-black text-white/40 uppercase tracking-[0.3em]">ENGINE v2.4.0</p>
              </div>

              <div className="absolute bottom-10 left-10 right-10 space-y-4">
                 <div className="flex items-baseline gap-3">
                    <p className="text-7xl font-black italic text-white leading-none uppercase tracking-tighter">{isMovementType ? distKm : gymLogs.length}</p>
                    <p className="text-xl font-black italic text-yellow-400 uppercase tracking-tighter leading-none">{isMovementType ? 'KM' : 'EX'}</p>
                 </div>
                 <div className="h-px w-full bg-white/10"></div>
                 <div className="flex justify-between items-center">
                    <div className="flex items-center gap-3">
                       <Clock size={18} className="text-zinc-500" />
                       <p className="text-2xl font-black italic text-white uppercase tracking-tighter leading-none">{timeFormatted}</p>
                    </div>
                    <div className="flex items-center gap-3">
                       <Target size={18} className="text-zinc-500" />
                       <p className="text-2xl font-black italic text-white uppercase tracking-tighter leading-none">ELITE</p>
                    </div>
                 </div>
              </div>
           </div>

           <div className="grid grid-cols-2 gap-4">
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-[2.5rem] text-center group hover:border-yellow-400/30 transition-all shadow-xl">
                 <p className="text-[10px] font-black text-zinc-600 uppercase italic tracking-widest mb-2">TELEMETRIA</p>
                 <p className="text-3xl font-black italic text-white tracking-tighter leading-none">{isMovementType ? distKm : gymLogs.length}<span className="text-sm text-zinc-700 ml-2 italic">{isMovementType ? 'KM' : 'EX'}</span></p>
              </div>
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-[2.5rem] text-center group hover:border-yellow-400/30 transition-all shadow-xl">
                 <p className="text-[10px] font-black text-zinc-600 uppercase italic tracking-widest mb-2">TEMPO BRUTO</p>
                 <p className="text-3xl font-black italic text-white tracking-tighter leading-none">{timeFormatted}</p>
              </div>
           </div>

           <div className="space-y-4 pt-4">
             <button 
               onClick={() => onComplete({ id: Date.now().toString(), type: mode, distance, duration: seconds, date: new Date().toISOString(), perceivedExertion: 8, photoUrl: photo || undefined, caloriesBurned: 300, gymSets: gymLogs })} 
               className="group w-full bg-yellow-400 text-black py-7 rounded-[2.5rem] font-black italic uppercase tracking-[0.2em] text-sm shadow-[0_20px_60px_rgba(250,204,21,0.2)] active:scale-95 flex items-center justify-center gap-4 transition-all hover:bg-yellow-300"
             >
               GRAVAR SESSÃO <ArrowRight size={20} strokeWidth={4} className="group-hover:translate-x-2 transition-transform" />
             </button>
             <p className="text-center text-[9px] font-black text-zinc-700 uppercase italic tracking-[0.5em]">Sync to Labs: Otimização de Performance</p>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[150] bg-black flex flex-col animate-in fade-in overflow-hidden">
       {isMovementType && <div id="interactive-map" className="absolute inset-0 opacity-40"></div>}
       
       {!isMovementType && mode === ActivityType.GYM && (
         <div className="flex-1 bg-[#050505] overflow-y-auto pt-32 pb-48 px-6 space-y-6 no-scrollbar">
            {gymLogs.map((log, idx) => (
              <div key={idx} className="bg-zinc-900 border border-zinc-800 rounded-[2.5rem] p-6 space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-black italic text-white uppercase tracking-tighter">{log.exerciseName}</h3>
                    <p className="text-[10px] font-black text-zinc-500 uppercase italic">Protocolo Ativo</p>
                  </div>
                  <button onClick={() => setGymLogs(gymLogs.filter((_, i) => i !== idx))} className="p-2 text-zinc-600 hover:text-red-500 transition-colors">
                    <Trash2 size={20} />
                  </button>
                </div>

                {log.photoUrl && (
                  <div className="relative w-full aspect-video rounded-2xl overflow-hidden border border-zinc-800 bg-black">
                    <img src={log.photoUrl} className="w-full h-full object-cover" />
                    <button 
                      onClick={() => setCapturingExerciseIdx(idx)} 
                      className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-md p-3 rounded-2xl text-yellow-400 border border-white/10 active:scale-90 transition-all"
                    >
                      <Camera size={18} strokeWidth={3} />
                    </button>
                  </div>
                )}

                <div className="flex gap-2">
                  {!log.photoUrl && (
                    <button 
                      onClick={() => setCapturingExerciseIdx(idx)}
                      className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 py-3 rounded-2xl flex items-center justify-center gap-2 text-[10px] font-black uppercase italic transition-all border border-zinc-700 active:scale-95"
                    >
                      <Camera size={14} strokeWidth={3} /> Tirar Foto
                    </button>
                  )}
                  <button 
                    onClick={() => {
                      const newLogs = [...gymLogs];
                      newLogs[idx].sets.push({ reps: 10, weight: 0 });
                      setGymLogs(newLogs);
                    }}
                    className="flex-1 bg-yellow-400/10 hover:bg-yellow-400/20 text-yellow-400 py-3 rounded-2xl flex items-center justify-center gap-2 text-[10px] font-black uppercase italic transition-all border border-yellow-400/10 active:scale-95"
                  >
                    <Plus size={14} strokeWidth={3} /> Add Série
                  </button>
                </div>

                <div className="space-y-2">
                  {log.sets.map((set, sIdx) => (
                    <div key={sIdx} className="flex items-center gap-3 bg-black/40 p-3 rounded-xl border border-zinc-800/50">
                      <span className="text-[10px] font-black text-zinc-700 w-4">S{sIdx+1}</span>
                      <div className="flex-1 grid grid-cols-2 gap-2">
                        <div className="relative">
                          <input 
                            type="number" 
                            value={set.reps} 
                            onChange={(e) => {
                              const newLogs = [...gymLogs];
                              newLogs[idx].sets[sIdx].reps = Number(e.target.value);
                              setGymLogs(newLogs);
                            }}
                            className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2 text-center text-xs font-black text-white outline-none"
                          />
                          <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[7px] font-black text-zinc-600">REPS</span>
                        </div>
                        <div className="relative">
                          <input 
                            type="number" 
                            value={set.weight} 
                            onChange={(e) => {
                              const newLogs = [...gymLogs];
                              newLogs[idx].sets[sIdx].weight = Number(e.target.value);
                              setGymLogs(newLogs);
                            }}
                            className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2 text-center text-xs font-black text-yellow-400 outline-none"
                          />
                          <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[7px] font-black text-zinc-600">KG</span>
                        </div>
                      </div>
                      <button onClick={() => {
                        const newLogs = [...gymLogs];
                        newLogs[idx].sets = newLogs[idx].sets.filter((_, i) => i !== sIdx);
                        setGymLogs(newLogs);
                      }} className="text-zinc-800 hover:text-red-500">
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}

            <button 
              onClick={() => setShowExPicker(true)}
              className="w-full bg-zinc-900 border-2 border-dashed border-zinc-800 p-8 rounded-[2.5rem] flex flex-col items-center gap-3 group hover:border-yellow-400 transition-all"
            >
              <Plus size={32} className="text-zinc-700 group-hover:text-yellow-400" />
              <span className="text-[10px] font-black uppercase italic tracking-widest text-zinc-600">Carregar Exercício</span>
            </button>
         </div>
       )}
       
       <div className="absolute top-0 left-0 right-0 p-6 z-20 bg-gradient-to-b from-black/90 to-transparent flex justify-between items-start">
          <div className="min-w-0">
             <p className="text-zinc-500 font-black italic uppercase text-[8px] tracking-widest">Tempo</p>
             <h2 className="text-4xl sm:text-5xl font-black italic text-white tabular-nums tracking-tighter">{Math.floor(seconds/60)}:{(seconds%60).toString().padStart(2,'0')}</h2>
          </div>
          <div className="text-right min-w-0">
             <p className="text-zinc-500 font-black italic uppercase text-[8px] tracking-widest">{isMovementType ? 'Km' : 'Exercícios'}</p>
             <h2 className="text-4xl sm:text-5xl font-black italic text-yellow-400 tracking-tighter truncate">
                {isMovementType ? (distance/1000).toFixed(2) : gymLogs.length}
             </h2>
          </div>
       </div>

       <div className="absolute bottom-10 left-0 right-0 p-6 z-20 flex justify-center gap-6">
          <button onClick={() => setIsPaused(!isPaused)} className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-zinc-900 border-2 border-zinc-800 flex items-center justify-center text-white active:scale-90 transition-all">{isPaused ? <Play size={32} /> : <Pause size={32} />}</button>
          {!mode?.includes('GYM') && (
            <button onClick={() => { setCapturingExerciseIdx(null); setCurrentCapturePreview(null); takePhoto(); }} className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-yellow-400 flex items-center justify-center text-black active:scale-90 transition-all"><Camera size={32} /></button>
          )}
          <button onClick={finish} className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-red-600 flex items-center justify-center text-white active:scale-90 transition-all"><Square size={32} /></button>
       </div>

       {capturingExerciseIdx !== null && (
         <div className="fixed inset-0 z-[600] bg-black flex flex-col animate-in fade-in slide-in-from-bottom duration-500">
            <div className="relative flex-1">
               {!currentCapturePreview ? (
                 <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
               ) : (
                 <img src={currentCapturePreview} className="w-full h-full object-cover animate-in fade-in duration-300" />
               )}
               
               {/* Overlay Visual para enquadramento */}
               {!currentCapturePreview && (
                 <div className="absolute inset-0 border-[40px] border-black/40 pointer-events-none flex items-center justify-center">
                    <div className="w-full h-2/3 border-2 border-dashed border-yellow-400/20 rounded-[3rem]"></div>
                 </div>
               )}

               <div className="absolute inset-0 flex flex-col justify-between p-8">
                  <div className="text-center mt-8">
                    <span className="bg-yellow-400 text-black px-6 py-3 rounded-full font-black italic uppercase text-[10px] tracking-widest shadow-2xl border-4 border-black">
                      {currentCapturePreview ? 'CONFIRMAR BIOMETRIA' : 'CAPTURA DE MOVIMENTO'}
                    </span>
                  </div>
                  
                  <div className="flex justify-center gap-8 pb-12">
                    {!currentCapturePreview ? (
                      <>
                        <button 
                          onClick={() => { setCapturingExerciseIdx(null); stopCamera(); }} 
                          className="w-16 h-16 rounded-full bg-zinc-900/80 backdrop-blur-md text-white flex items-center justify-center border-2 border-zinc-800"
                        >
                          <X size={32} />
                        </button>
                        <button 
                          onClick={takePhoto} 
                          className="w-24 h-24 rounded-full bg-yellow-400 text-black flex items-center justify-center shadow-[0_0_60px_rgba(250,204,21,0.4)] border-[8px] border-black active:scale-90 transition-all"
                        >
                          <Camera size={40} strokeWidth={3} />
                        </button>
                        <div className="w-16 h-16"></div>
                      </>
                    ) : (
                      <>
                        <button 
                          onClick={discardCapture} 
                          className="w-20 h-20 rounded-full bg-zinc-900/80 backdrop-blur-md text-red-500 flex items-center justify-center border-2 border-zinc-800 shadow-xl active:scale-90 transition-all"
                        >
                          <RotateCcw size={36} />
                        </button>
                        <button 
                          onClick={confirmCapture} 
                          className="w-20 h-20 rounded-full bg-yellow-400 text-black flex items-center justify-center shadow-[0_0_50px_rgba(250,204,21,0.3)] border-4 border-black active:scale-90 transition-all"
                        >
                          <Check size={40} strokeWidth={4} />
                        </button>
                      </>
                    )}
                  </div>
               </div>
            </div>
         </div>
       )}

       {showExPicker && (
         <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-2xl p-8 animate-in slide-in-from-bottom duration-500 overflow-y-auto no-scrollbar">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-2xl font-black italic text-white uppercase tracking-tighter">Protocolos</h3>
              <button onClick={() => setShowExPicker(false)} className="p-3 bg-zinc-900 rounded-xl text-zinc-500">
                <X size={24} />
              </button>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {MOCK_EXERCISES.map(ex => (
                <button key={ex.id} onClick={() => {
                  setGymLogs(prev => [...prev, { exerciseId: ex.id, exerciseName: ex.name, sets: [{ reps: 10, weight: 0 }] }]);
                  setShowExPicker(false);
                }} className="bg-zinc-900 border border-zinc-800 p-4 rounded-3xl flex items-center gap-4 text-left hover:border-yellow-400 transition-all group">
                  <img src={ex.imageUrl} className="w-16 h-16 rounded-xl object-cover grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 transition-all" />
                  <div>
                    <h4 className="text-lg font-black italic text-white uppercase leading-none">{ex.name}</h4>
                    <p className="text-[8px] font-black text-zinc-600 uppercase italic mt-1">{ex.category} • {ex.equipment}</p>
                  </div>
                </button>
              ))}
            </div>
         </div>
       )}

       <div className="hidden"><video ref={videoRef} autoPlay playsInline muted /><canvas ref={canvasRef} /></div>
    </div>
  );
};

const MetricTile = ({ label, val, unit }: any) => (
  <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-[1.8rem] text-center shadow-inner hover:border-yellow-400/20 transition-colors">
    <p className="text-[8px] font-black text-zinc-600 uppercase italic tracking-widest mb-2">{label}</p>
    <p className="text-3xl font-black italic text-white truncate tabular-nums leading-none">{val}<span className="text-xs text-zinc-700 ml-1.5">{unit}</span></p>
  </div>
);

const ModeBtn = ({ icon, label, onClick }: any) => (
  <button onClick={onClick} className="bg-zinc-900 border border-zinc-800 p-6 rounded-[2rem] flex flex-col items-center gap-3 active:scale-95 transition-all w-full group hover:border-yellow-400/40">
    <div className="text-zinc-600 group-hover:text-yellow-400 transition-colors">{icon}</div>
    <span className="text-[10px] font-black uppercase italic tracking-widest text-zinc-500 group-hover:text-white transition-colors">{label}</span>
  </button>
);

export default Tracker;
