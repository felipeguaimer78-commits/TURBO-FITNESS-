
import React, { useState, useRef } from 'react';
import { Activity, ActivityType, UserProfile, UserPreferences } from '../types';
import { 
  Camera, 
  Settings, 
  LogOut, 
  ChevronRight, 
  Trophy, 
  Flame, 
  Zap, 
  Footprints, 
  Bike, 
  Dumbbell, 
  MapPin, 
  Clock, 
  Award,
  Shield,
  Bell,
  Check,
  X,
  User as UserIcon,
  Star,
  Activity as PerformanceIcon,
  MessageSquare,
  Send,
  Loader2,
  Eye,
  EyeOff,
  Globe,
  Map as MapIcon,
  Share2
} from 'lucide-react';

interface ProfileProps {
  activities: Activity[];
  userProfile: UserProfile;
  onUpdateProfile: (p: UserProfile) => void;
  onLogout: () => void;
}

const Profile: React.FC<ProfileProps> = ({ activities, userProfile, onUpdateProfile, onLogout }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [newName, setNewName] = useState(userProfile.name);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [isSendingFeedback, setIsSendingFeedback] = useState(false);
  const [feedbackSent, setFeedbackSent] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Default preferences if not present
  const preferences: UserPreferences = userProfile.preferences || {
    isPublicProfile: true,
    isAnonymousMode: false,
    useMetricSystem: true,
    hideLocationData: false,
    shareTelemetry: true
  };

  const totalKm = activities.reduce((acc, curr) => acc + (curr.distance || 0), 0) / 1000;
  const totalCalories = activities.reduce((acc, curr) => acc + (curr.caloriesBurned || 0), 0);
  const totalDurationSeconds = activities.reduce((acc, curr) => acc + curr.duration, 0);
  
  const countByType = (type: ActivityType) => activities.filter(a => a.type === type).length;
  const lastActivity = activities.length > 0 ? activities[0] : null;
  const streak = activities.length > 5 ? 7 : activities.length > 0 ? activities.length : 0;

  const getLevel = () => {
    const total = activities.length;
    if (total > 50) return { name: 'ELITE', color: 'text-red-500', bg: 'bg-red-500/10', icon: <Star size={14} className="fill-red-500" /> };
    if (total > 20) return { name: 'TURBO', color: 'text-yellow-400', bg: 'bg-yellow-400/10', icon: <Zap size={14} className="fill-yellow-400" /> };
    if (total > 5) return { name: 'ATIVO', color: 'text-emerald-400', bg: 'bg-emerald-400/10', icon: <PerformanceIcon size={14} /> };
    return { name: 'INICIANTE', color: 'text-zinc-500', bg: 'bg-zinc-800', icon: <UserIcon size={14} /> };
  };

  const level = getLevel();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUpdateProfile({ ...userProfile, photoUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const saveName = () => {
    onUpdateProfile({ ...userProfile, name: newName });
    setIsEditing(false);
  };

  const updatePreference = (key: keyof UserPreferences) => {
    const newPrefs = { ...preferences, [key]: !preferences[key] };
    onUpdateProfile({ ...userProfile, preferences: newPrefs });
  };

  const sendFeedback = async () => {
    if (!feedbackText.trim()) return;
    setIsSendingFeedback(true);
    await new Promise(r => setTimeout(r, 1500));
    setIsSendingFeedback(false);
    setFeedbackSent(true);
    setFeedbackText('');
    setTimeout(() => {
      setFeedbackSent(false);
      setShowFeedback(false);
    }, 2000);
  };

  return (
    <div className="space-y-10 pb-16 animate-in fade-in slide-in-from-bottom-8 duration-700">
      <section className="flex flex-col items-center gap-8 mt-6">
        <div className="relative group">
          <div className={`w-40 h-40 sm:w-44 sm:h-44 rounded-full border-4 ${isEditing ? 'border-yellow-400 scale-105 shadow-[0_0_40px_rgba(250,204,21,0.3)]' : 'border-zinc-800'} transition-all overflow-hidden shadow-2xl bg-zinc-900`}>
            {userProfile.photoUrl ? (
              <img src={userProfile.photoUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="Profile" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-zinc-800">
                <UserIcon size={96} />
              </div>
            )}
          </div>
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="absolute bottom-2 right-2 bg-yellow-400 text-black p-4 rounded-full border-[6px] border-[#050505] shadow-2xl hover:scale-110 active:scale-90 transition-all"
          >
            <Camera size={22} strokeWidth={3} />
          </button>
          <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
        </div>

        <div className="text-center space-y-3 w-full max-w-sm px-4">
          {isEditing ? (
            <div className="flex items-center gap-3 justify-center">
              <input 
                value={newName} 
                onChange={(e) => setNewName(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 text-center font-black italic text-3xl uppercase tracking-tighter text-white outline-none focus:border-yellow-400 px-6 py-3 rounded-[1.5rem] shadow-inner"
                autoFocus
              />
              <button onClick={saveName} className="p-4 bg-yellow-400 text-black rounded-2xl shadow-xl active:scale-90 transition-all"><Check size={24} strokeWidth={3}/></button>
              <button onClick={() => {setNewName(userProfile.name); setIsEditing(false)}} className="p-4 bg-zinc-800 text-zinc-500 rounded-2xl active:scale-90 transition-all hover:text-white"><X size={24}/></button>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-4 group">
              <h2 className="text-4xl sm:text-5xl font-black italic text-white uppercase tracking-tighter leading-none">{userProfile.name}</h2>
              <button onClick={() => setIsEditing(true)} className="text-zinc-700 hover:text-yellow-400 transition-all p-2 bg-zinc-900/50 rounded-xl active:scale-90">
                <Settings size={22} />
              </button>
            </div>
          )}
          <div className="flex items-center justify-center gap-3 pt-3">
            <span className={`px-5 py-2 rounded-full text-[10px] font-black italic tracking-[0.3em] flex items-center gap-2.5 shadow-xl ${level.bg} ${level.color}`}>
              {level.icon} {level.name}
            </span>
            <div className="flex items-center gap-2 bg-yellow-400/10 text-yellow-400 px-5 py-2 rounded-full text-[10px] font-black italic shadow-inner tracking-widest border border-yellow-400/10">
               <Flame size={14} fill="currentColor" /> {streak} DIAS STREAK
            </div>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-3 gap-4">
        <StatsTile label="TOTAL KM" val={totalKm.toFixed(1)} icon={<MapPin size={18}/>} />
        <StatsTile label="TOTAL KCAL" val={totalCalories} icon={<Flame size={18}/>} />
        <StatsTile label="TOTAL HRS" val={(totalDurationSeconds / 3600).toFixed(1)} icon={<Clock size={18}/>} />
      </section>

      {/* Preferências de Exibição e Privacidade */}
      <section className="bg-zinc-900/40 border border-zinc-800 rounded-[3rem] p-8 sm:p-10 space-y-8 shadow-2xl">
        <div className="flex items-center justify-between px-2 mb-2">
          <div className="space-y-1">
            <h3 className="text-xl font-black italic text-white uppercase tracking-tighter leading-none">AJUSTES DE SISTEMA</h3>
            <p className="text-[10px] font-black text-yellow-400 uppercase italic tracking-[0.3em]">Privacidade & Visual</p>
          </div>
          <Shield size={24} className="text-zinc-700" />
        </div>

        <div className="space-y-4">
          <PreferenceToggle 
            icon={<Globe size={20} />} 
            label="Perfil Público" 
            description="Permite que outros atletas Turbo vejam suas conquistas."
            isActive={preferences.isPublicProfile}
            onToggle={() => updatePreference('isPublicProfile')}
          />
          <PreferenceToggle 
            icon={<EyeOff size={20} />} 
            label="Modo Anônimo" 
            description="Esconde seu nome em leaderboards globais."
            isActive={preferences.isAnonymousMode}
            onToggle={() => updatePreference('isAnonymousMode')}
          />
          <PreferenceToggle 
            icon={<Dumbbell size={20} />} 
            label="Sistema Métrico" 
            description="Usa KM/KG em vez de Milhas/Libras."
            isActive={preferences.useMetricSystem}
            onToggle={() => updatePreference('useMetricSystem')}
          />
          <PreferenceToggle 
            icon={<MapIcon size={20} />} 
            label="Ocultar Rotas" 
            description="Oculta o ponto inicial e final de suas atividades de GPS."
            isActive={preferences.hideLocationData}
            onToggle={() => updatePreference('hideLocationData')}
          />
          <PreferenceToggle 
            icon={<Share2 size={20} />} 
            label="Compartilhar Bio-Dados" 
            description="Envia telemetria anônima para melhorar o motor IA."
            isActive={preferences.shareTelemetry}
            onToggle={() => updatePreference('shareTelemetry')}
          />
        </div>
      </section>

      <section className="bg-gradient-to-br from-yellow-400/10 to-transparent border border-yellow-400/20 rounded-[3rem] p-8 sm:p-10 space-y-6 shadow-2xl shadow-yellow-400/5">
        <div className="flex items-center gap-4">
          <div className="p-4 bg-yellow-400 rounded-2xl text-black shadow-xl shadow-yellow-400/10">
            <MessageSquare size={28} strokeWidth={3} />
          </div>
          <div className="space-y-1">
            <h3 className="text-xl font-black italic text-white uppercase tracking-tighter leading-none">CANAL DE FEEDBACK</h3>
            <p className="text-[10px] font-black text-yellow-400/60 uppercase italic tracking-[0.4em]">Bio-Comunicação Beta</p>
          </div>
        </div>
        
        <p className="text-xs sm:text-sm text-zinc-400 font-bold italic leading-relaxed uppercase tracking-tight pl-1">
          O Turbo Fitness está em constante evolução bio-sincrônica. Sua telemetria visual e experiência moldam o futuro do nosso ecossistema.
        </p>

        {!showFeedback ? (
          <button 
            onClick={() => setShowFeedback(true)}
            className="w-full bg-zinc-900/60 border border-zinc-800 py-5 rounded-[1.5rem] font-black italic text-xs uppercase tracking-[0.3em] text-zinc-400 hover:text-white transition-all active:scale-[0.98] shadow-xl hover:border-yellow-400/20 flex items-center justify-center gap-3"
          >
            <Share2 size={16} /> ENVIAR SUGESTÃO DE PERFORMANCE
          </button>
        ) : (
          <div className="space-y-5 animate-in slide-in-from-top-4 duration-500">
            <textarea 
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              className="w-full bg-black border border-zinc-800 rounded-[2rem] p-6 text-xs sm:text-sm font-bold text-white placeholder:text-zinc-800 outline-none focus:border-yellow-400 min-h-[140px] resize-none transition-all shadow-inner"
              placeholder="O que o sistema Turbo pode fazer melhor para o seu treino?"
            />
            <div className="flex gap-3">
              <button 
                onClick={sendFeedback}
                disabled={isSendingFeedback || !feedbackText.trim() || feedbackSent}
                className="flex-1 bg-yellow-400 text-black py-5 rounded-2xl font-black italic text-xs uppercase tracking-widest flex items-center justify-center gap-3 disabled:opacity-40 active:scale-95 transition-all shadow-2xl shadow-yellow-400/10"
              >
                {isSendingFeedback ? <Loader2 size={18} className="animate-spin" /> : (feedbackSent ? <Check size={18} strokeWidth={3} /> : <Send size={18} />)}
                {feedbackSent ? 'SINCRONIZADO' : 'TRANSMITIR DADOS'}
              </button>
              <button 
                onClick={() => setShowFeedback(false)}
                className="px-6 bg-zinc-900 border border-zinc-800 text-zinc-500 rounded-2xl active:scale-95 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </div>
        )}
      </section>

      <section className="bg-zinc-900/40 border border-zinc-800 rounded-[3rem] p-8 sm:p-10 space-y-8 shadow-2xl">
        <h3 className="text-[11px] font-black text-zinc-600 uppercase tracking-[0.4em] italic px-2">Arsenal de Atividades</h3>
        <div className="grid grid-cols-2 gap-4">
          <ActivityMiniCard icon={<Footprints size={22}/>} label="Corridas" count={countByType(ActivityType.RUN)} color="text-emerald-400" />
          <ActivityMiniCard icon={<Bike size={22}/>} label="Pedais" count={countByType(ActivityType.CYCLE)} color="text-yellow-400" />
          <ActivityMiniCard icon={<Dumbbell size={22}/>} label="Treinos" count={countByType(ActivityType.GYM)} color="text-orange-400" />
          <ActivityMiniCard icon={<MapPin size={22}/>} label="Trilhas" count={countByType(ActivityType.WALK)} color="text-blue-400" />
        </div>
      </section>

      <section className="space-y-5 px-1">
        <h3 className="text-[11px] font-black text-zinc-600 uppercase tracking-[0.4em] italic px-6">Configurações do OS</h3>
        <div className="space-y-4">
          <MenuLink icon={<Shield size={20}/>} label="Privacidade & Bio-Segurança" />
          <MenuLink icon={<Bell size={20}/>} label="Gerenciar Notificações" />
          <MenuLink icon={<Award size={20}/>} label="Hall da Fama Elite" />
          
          <button 
            onClick={onLogout}
            className="w-full bg-red-500/5 border border-red-500/20 p-7 rounded-[2.5rem] flex items-center justify-between group active:scale-[0.98] transition-all hover:bg-red-500/10 shadow-xl"
          >
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 rounded-2xl bg-red-500/20 flex items-center justify-center text-red-500 group-hover:rotate-12 transition-transform shadow-2xl shadow-red-500/20">
                <LogOut size={28} />
              </div>
              <span className="text-lg font-black italic text-red-500 uppercase tracking-tighter leading-none">Finalizar Protocolo</span>
            </div>
            <ChevronRight size={20} className="text-red-500/30 group-hover:text-red-500 transition-colors" />
          </button>
        </div>
      </section>

      <footer className="text-center space-y-3 py-10 border-t border-zinc-900 mt-12 mx-6">
         <div className="flex items-center justify-center gap-4">
            <Zap size={16} className="text-yellow-400" fill="currentColor" />
            <p className="text-[11px] font-black text-zinc-700 uppercase italic tracking-[0.6em]">Turbo Fitness OS v2.4.0</p>
         </div>
         <p className="text-[10px] font-bold text-zinc-800 uppercase tracking-[0.2em] leading-relaxed">Engineered for High Performance Athletes<br/>© 2025 ELITE PERFORMANCE LABS</p>
      </footer>
    </div>
  );
};

const StatsTile = ({ label, val, icon }: { label: string, val: any, icon: React.ReactNode }) => (
  <div className="bg-zinc-900 border border-zinc-800 p-6 sm:p-8 rounded-[2.5rem] flex flex-col items-center text-center gap-3 group hover:border-yellow-400/40 transition-all shadow-2xl active:scale-95">
    <div className="text-zinc-700 group-hover:text-yellow-400 transition-colors duration-500 transform group-hover:scale-110">{icon}</div>
    <div className="space-y-1">
      <p className="text-[9px] font-black text-zinc-600 uppercase tracking-[0.2em] italic leading-none">{label}</p>
      <p className="text-3xl font-black italic text-white tracking-tighter leading-none">{val}</p>
    </div>
  </div>
);

const ActivityMiniCard = ({ icon, label, count, color }: { icon: React.ReactNode, label: string, count: number, color: string }) => (
  <div className="bg-black border border-zinc-800/50 p-6 rounded-[2rem] space-y-4 shadow-inner active:scale-95 transition-all group">
    <div className={`p-4 rounded-2xl bg-zinc-900 inline-block ${color} shadow-2xl group-hover:scale-110 transition-transform`}>{icon}</div>
    <div className="space-y-1">
      <p className="text-[9px] font-black text-zinc-700 uppercase italic tracking-widest leading-none pl-1">{label}</p>
      <p className="text-4xl font-black italic text-white tabular-nums tracking-tighter leading-none">{count}</p>
    </div>
  </div>
);

const PreferenceToggle = ({ icon, label, description, isActive, onToggle }: { icon: React.ReactNode, label: string, description: string, isActive: boolean, onToggle: () => void }) => (
  <button 
    onClick={onToggle}
    className="w-full bg-zinc-900/60 border border-zinc-800 p-6 rounded-[2rem] flex items-center justify-between group active:scale-[0.99] transition-all hover:bg-zinc-900 shadow-xl"
  >
    <div className="flex items-center gap-6">
      <div className={`w-12 h-12 rounded-xl border flex items-center justify-center transition-all ${isActive ? 'bg-yellow-400 border-yellow-400 text-black shadow-lg shadow-yellow-400/10' : 'bg-black border-zinc-800 text-zinc-700'}`}>
        {icon}
      </div>
      <div className="text-left space-y-0.5">
        <span className={`text-sm font-black italic uppercase tracking-tight leading-none transition-colors ${isActive ? 'text-white' : 'text-zinc-500'}`}>{label}</span>
        <p className="text-[9px] font-bold text-zinc-700 uppercase italic tracking-tight line-clamp-1">{description}</p>
      </div>
    </div>
    <div className={`w-12 h-6 rounded-full relative transition-all duration-300 ${isActive ? 'bg-yellow-400' : 'bg-zinc-800'}`}>
       <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-md transition-all duration-300 ${isActive ? 'left-7' : 'left-1'}`} />
    </div>
  </button>
);

const MenuLink = ({ icon, label }: { icon: React.ReactNode, label: string }) => (
  <button className="w-full bg-zinc-900/40 border border-zinc-800 p-7 rounded-[2.5rem] flex items-center justify-between group active:scale-[0.98] transition-all hover:bg-zinc-900 shadow-xl">
    <div className="flex items-center gap-6">
      <div className="w-14 h-14 rounded-2xl bg-black border border-zinc-800 flex items-center justify-center text-zinc-600 group-hover:text-yellow-400 transition-all shadow-inner">
        {icon}
      </div>
      <span className="text-lg font-black italic text-zinc-300 uppercase tracking-tighter leading-none">{label}</span>
    </div>
    <ChevronRight size={22} className="text-zinc-800 group-hover:text-yellow-400 transition-all group-hover:translate-x-1.5" />
  </button>
);

export default Profile;
