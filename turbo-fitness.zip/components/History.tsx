
import React from 'react';
import { Activity, ActivityType } from '../types';
import { Bike, Footprints, Calendar, ArrowRight } from 'lucide-react';

interface HistoryProps {
  activities: Activity[];
}

const History: React.FC<HistoryProps> = ({ activities }) => {
  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-2xl font-black">Histórico</h2>
        <p className="text-zinc-500 text-sm">Seu progresso, sessão por sessão.</p>
      </header>

      <div className="space-y-3">
        {activities.map((activity) => (
          <div key={activity.id} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 flex items-center gap-4 active:scale-[0.98] transition-all">
            <div className="w-12 h-12 rounded-xl bg-zinc-800 flex items-center justify-center text-emerald-500">
              {activity.type === ActivityType.RUN ? <Footprints size={24} /> : <Bike size={24} />}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-zinc-500 flex items-center gap-1">
                  <Calendar size={10} />
                  {new Date(activity.date).toLocaleDateString('pt-BR')}
                </span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${activity.type === ActivityType.RUN ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'}`}>
                  {activity.type === ActivityType.RUN ? 'CORRIDA' : 'CICLISMO'}
                </span>
              </div>
              <h4 className="font-black text-lg">{(activity.distance / 1000).toFixed(2)} km</h4>
            </div>
            <div className="text-right">
              <p className="text-sm font-bold">{(activity.duration / 60).toFixed(0)} min</p>
              <p className="text-[10px] text-zinc-500 font-bold uppercase">Esforço: {activity.perceivedExertion}/10</p>
            </div>
            <ArrowRight size={16} className="text-zinc-700" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default History;
